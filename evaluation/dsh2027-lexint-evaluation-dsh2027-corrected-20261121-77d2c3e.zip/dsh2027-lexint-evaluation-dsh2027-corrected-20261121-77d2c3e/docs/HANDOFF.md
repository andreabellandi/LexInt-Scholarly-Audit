# LexO-server — handoff per attività Codex

Aggiornato al 21 novembre 2026 con la correzione focalizzata della valutazione
DSH 2027 LexInt sul branch `codex/dsh2027-corrections`, partito dal commit
`3fee281c939350947927c002fc807b57c4bad23f` di `origin/master`. `README.md`
principale, le quattro ontologie/shapes contrattuali e il manoscritto DSH2027
sono rimasti invariati. Il contratto approvato usa esclusivamente
`lexint:targetAssertion`; il distinto `pub:targetAssertion` resta singolare.
`evaluation/dsh2027/namespace-contract-audit.md` documenta fonti, hash,
consistency check e proposta di correzione del manoscritto, non applicata.

La correzione P0-A mantiene il test MemoryStore come `T09-L0` e aggiunge
`T09-GraphDB`: il vero `LexIntPublicationManager` usa un hook in-process non
configurabile da REST/property, lancia dopo le scritture provvisorie e prima di
commit, quindi connessioni `HTTPRepositoryConnection` indipendenti confrontano
isomorficamente active, V1, V2, records e audit/ledger. Il run diagnostico
completo `dsh2027-corrections-diagnostic-20261121-3` ha osservato hook=1,
eccezione propagata, rollback identico e successivo publish ordinario HTTP 201.

La correzione P0-B sostituisce i vecchi predicati CQ permissivi con un unico
comparatore multinsieme: tutte le variabili e i termini RDF conservano tipo,
datatype, lingua e molteplicità; gli ID runtime sono risolti da mappe prodotte
dai servizi, mai dall'output SPARQL. CQ05 risolve i target per predicato RDF,
non per ordine della risposta. Quattro mutazioni avversarie (associazioni
CQ01/CQ04/CQ05 e duplicato CQ07) devono essere respinte. Lo stesso diagnostico
ha ottenuto T01–T12 12/12, CQ01–CQ07 7/7 esatti e CE1–CE3 3/3 coincidenti con
l'oracle; il default graph era vuoto e il boundary GraphDB esterno non era
raggiungibile. Il run resta marcato `worktree_dirty=true` ed è solo una prova
pre-commit: il pacchetto consegnabile deve essere rigenerato da un checkout
pulito del commit definitivo, con SHA e image ID nel manifest del run.

Verifiche locali: i test mirati di workflow, L0, comparatore e namespace sono
20/20; `mvn -o verify` ha superato 372 test unitari/repository e generato il WAR
con 21 IT opt-in correttamente saltati fuori dagli ambienti dedicati. Il build
Docker ha rieseguito gli stessi 372 test. Stack trace dei percorsi d'errore
simulati, warning Lucene `Unsafe` e warning checksum dell'artefatto Maven
vendorizzato sono attesi e non hanno prodotto failure.

Non resta lavoro di implementazione noto. Il gate di consegna è il run completo
da commit pulito e il controllo del nuovo ZIP/manifest. Limiti dichiarati:
lock di pubblicazione JVM singola istanza, nessuna prova di concorrenza
multi-istanza, niente RDF 1.2, identità demo `DECLARED`; la garanzia anti-bypass
richiede i guard applicativi più ACL/rete GraphDB equivalenti alla topologia
valutata. Gli esempi non certificano verità storica o lessicografica.

Aggiornato al 20 novembre 2026 con l'implementazione locale di LexInt
Management e LexInt Publication & Audit su `master`, partito allineato a
`origin/master` (`0c15581df2207756a40b97c443b45a1c6d0b5429`). Il lavoro non è
stato committato né distribuito. `README.md` è rimasto byte-identico.

Il WAR espone ora le risorse Swagger `LexInt Management`, `LexInt Versions` e
`LexInt Publication & Audit`: CRUD di claim/target/decisione, finalizzazione,
baseline e draft, preview senza scritture, publish per-target con ETag e
idempotenza persistente, snapshot Turtle, listing, audit storico e verify.
Tutto usa `RepositoryTarget.LEXICON`; records, audit, shapes e snapshot sono
named graph separati e il default graph resta vuoto. Un writer centralizzato
assegna creator/created/modified a ogni individuo runtime. Username e ruolo
publisher sono risolti server-side; in free mode l'identità è `DECLARED` e il
publish resta disabilitato per default.

Le due ontologie Turtle sono nel manifest schema e le due shape hanno manifest,
checksum e rollback dedicati. Su richiesta esplicita del maintainer,
la proprietà della claim è stata uniformata ovunque al singolare
`lexint:targetAssertion`, inclusi i TTL sorgente sotto
`/Users/andrea/Documents/Submissions/UD 2026/lexint`; il distinto
`pub:targetAssertion` non è cambiato. Il vecchio namespace LexInt non è stato
introdotto.

La pubblicazione costruisce `(G_source - D) + I`, controlla drift, autorizza
ogni target con una decisione finalizzata, committa snapshot/current/ledger e
primo report in una sola transazione. Retry identici non creano nuove IRI.
Verify ricostruisce lo specifico delta storico e conserva JSON bounded di
missing/unexpected e codici diagnostici nel report. Link, tipi, metadati,
decisioni e versioni storiche vengono rivalidati; un input danneggiato genera
un nuovo report persistito `INDETERMINATE`, non un falso PASS. Il dettaglio
versione include la storia audit della publication associata. Il write guard
blocca entry create/update, status e metadata diretti soltanto quando i flag
managed sono attivi e la lingua possiede una baseline corrente; con i flag
default i servizi esistenti restano invariati.

La configurazione dei graph è validata centralmente sia al bootstrap sia a
ogni apertura LexInt contro graph esatti e famiglie lessicali, testuali,
attestazioni, annotazioni e WordNet. I Bearer mancanti o malformati vengono
rifiutati prima dell'accesso al provider. Payload JSON ed export snapshot sono
bounded durante lo streaming; tutte le route applicano inoltre un rate limit
per identità, con cache LRU bounded e proprietà configurabili.

Verifica eseguita:

- `mvn -DskipTests compile`: riuscita;
- `GraphDbBootstrapTest`: 6 test superati;
- `LexIntWorkflowTest`, `LexIntAuthPolicyTest`, `LexIntApiContractTest` e
  `LexIntRateLimiterTest`, `LexIntGraphGuardIntegrationTest`: 21 test superati,
  inclusi SHACL
  fail-closed, CRUD e finalizzazione, metadata, auth/ruolo, V1→V2→V3,
  preview read-only, rollback ETag e post-write, idempotenza scoped per
  principal, baseline V1 stabile, target sovrapposti, claim parziale, audit
  storico fail-closed, mismatch di policy/versione/claim, rate limit,
  concorrenza sullo stesso scope, drift e blocco dei writer lessicali nello
  scope gestito;
- `mvn verify`: 365 test unitari/repository superati senza failure, errori o
  skip; WAR generato; 20 E2E, inclusa la nuova `LexIntServicesIT`, compilati e
  saltati perché gli opt-in e i deployment Tomcat/GraphDB dedicati non erano
  configurati.

Limiti noti: RDF4J 3.7/Java 8 non implementa direttamente
`XoneConstraintComponent`; il TTL resta invariato e il validator applica lo
stesso vincolo fail-closed prima della revalidazione ShaclSail degli altri
componenti. Il runtime v1 rifiuta RDF 1.2 `rdf:reifies`. La serializzazione
publish usa un lock JVM e richiede una sola istanza writer; non è un lock
distribuito; anche il rate limit è locale alla JVM e richiede un limite
coordinato al reverse proxy in un deployment multi-istanza. Differenze in
componenti blank-node non isomorfe producono `INDETERMINATE`. Restano da
eseguire gli E2E LexInt su Tomcat/GraphDB isolati; prima del rollout vanno
inoltre configurati permessi GraphDB che impediscano writer esterni. Maven ha
segnalato il certificato scaduto del repository metadata legacy
`maven.java.net`, senza impedire build o test. Il prossimo passo raccomandato è
distribuire il WAR in un ambiente dedicato, eseguire il workflow completo via
REST e verificare direttamente named graph e default graph. La guida completa
è `docs/lexint-services.md`.

Aggiornato al 12 novembre 2026 con l'integrazione del branch `cpp` in `master`.
Il merge parte da `origin/master` aggiornato e conserva integralmente
la nuova API WordNet, l'organizzazione e la ricerca testuale e aggiunge i sei
endpoint CPP, le ontologie CPP 0.2.1/CollScore 1.2.0 e il relativo bootstrap
Turtle/RDF/XML. `README.md` è rimasto invariato e non è stato eseguito alcun
deploy.

I conflitti sono stati risolti mantenendo l'ordine di bootstrap isolato di
WordNet e applicando il riconoscimento del formato per estensione soltanto al
manifest lessicale misto. La normalizzazione effettiva dell'estrazione collocati
è ora condivisa tra Lucene e CPP e comprende anche `nodeField` e
`collocateField`: `TOKEN`, `LEMMA` e `POS` vengono normalizzati, validati e
conservati nel record CPP; selettori non supportati sono rifiutati prima di
qualsiasi scrittura. Un nuovo test verifica il round-trip CPP `LEMMA` → `POS`
e il rollback del valore non valido.

Verifica eseguita sul risultato integrato:

- compilazione Maven offline riuscita;
- suite mirata CPP/WordNet/Lucene: 65 test superati;
- `mvn -o test`: 341 test unitari/repository superati, nessun failure, errore o
  skip;
- `mvn -o verify`: stessi 341 test superati e WAR generato; 19 end-to-end
  compilati ma skipped perché non erano configurati gli opt-in e i deployment
  dedicati per CPP, testi, WordNet e Web Annotation;
- restano attesi gli stack trace dei percorsi d'errore simulati, i warning Maven
  sui metadata/checksum legacy e il warning Lucene `MMapDirectory` sul JDK
  moderno.

Rimane da eseguire il collaudo remoto CPP su Tomcat e repository GraphDB
esclusivamente dedicati, seguendo `docs/cpp-run-services.md`; l'E2E WordNet era
già stato completato separatamente prima del merge. Restano validi i limiti CPP
documentati: un solo writer per repository, provenienza dichiarata senza prova
di riesecuzione storica e nessuna migrazione automatica degli score FrAC legacy.
Il prossimo passo raccomandato è distribuire il WAR in un ambiente isolato,
eseguire `CppRunsIT` con opt-in e verificare il graph CPP insieme ai tre
repository esistenti.

Aggiornato al 9 novembre 2026 con l'implementazione completa della nuova API
WordNet. Il lavoro è sul branch `master`, che è stato aggiornato e verificato
allineato a `origin/master` prima delle modifiche. I nuovi E2E WordNet e la loro
procedura sono nel commit `922e325` (`Add remote WordNet end-to-end coverage`).
`README.md` è rimasto invariato e non è stato eseguito alcun deploy permanente.

La verifica remota WordNet non è più un'attività pendente. È stata aggiunta la
suite opt-in `WordnetServicesIT`, eseguita contro un Tomcat e tre repository
GraphDB temporanei dedicati. I due scenari controllano la provenance dello
schema e il lifecycle REST completo di root, Entry, Form, Synset, Sense,
Relation e workflow; interrogano inoltre direttamente `LexOWordnets` per
verificare named graph applicativo, schema invariato, default graph vuoto e
rollback delle mutazioni rifiutate. La procedura e le proprietà Maven sono
documentate in `docs/wordnet-services.md`; il cleanup REST e RDF viene sempre
eseguito in `finally`.

È stato aggiunto il terzo target `RepositoryTarget.WORDNET`, instradato da
`GraphDbUtil` esclusivamente al repository configurabile `LexOWordnets` tramite
`WordnetGraphDb.*`. Il bootstrap crea il repository dal nuovo template GraphDB
10, importa in modo transazionale e idempotente lo schema nel graph WordNet
dedicato e conserva il checksum in un bootstrap graph separato. Il Turtle GWA
1.4 allegato è vendorizzato senza modifiche con SHA-256
`deecbb23eb84ff9f9a3d40adb6077810f2a0bd6ab9ccedd7d0b3b26af3f422bb`;
la conversione RDF/XML runtime è graph-isomorphic (646 statement). Le dipendenze
LIME/OntoLex/SKOS/SynSem/VarTrans e la provenance del profilo API 1.4 sono
incluse nel manifest locale. Il bootstrap WordNet non esegue gli indici
lessicali e non cancella application graph.

La classe `service/Wordnet.java`, con Swagger `Wordnet`, espone tutti e soli gli
endpoint previsti per root, entry, form, sense, synset, relazioni, schema e i due
servizi di stato Entry. I manager sotto `manager/wordnet` mantengono un solo
application named graph per WordNet, ID Base64URL, audit, transazioni, filtri,
paginazione, proiezioni `sections`, optimistic concurrency, liste
`wn:memberList` di Sense IRI e vincoli di cancellazione/riferimento. Le
relazioni VarTrans sono risorse nominate validate contro lo schema e non
materializzano inverse. I PATCH dei figli sono piatti e presence-aware e
modificano campi strutturali, annotazioni native e metadati nella stessa
transazione.

L'audit conclusivo rispetto alla specifica ha inoltre reso indipendente il
fallback della dimensione del pool WordNet, corretto le proiezioni esplicite in
modo che non includano campi `core`/nativi non richiesti e aggiunto
`direction=in|out|both` alle sezioni relazioni di Sense e Synset. I controlli di
concorrenza sono ora eseguiti nella transazione di mutazione; root, ownership,
cardinalità di Sense/Synset e proprietà esclusiva delle celle RDF list vengono
verificati prima delle modifiche. I DTO PATCH rilevano anche campi immutabili o
workflow riservati forniti esplicitamente come `null`.

L'ultimo ampliamento dei test obbligatori ha individuato e corretto l'ordine
del controllo sulle liste membri: il collegamento `wn:memberList` non viene più
rimosso prima di verificarne l'ownership. Aggiunta, spostamento, riordino e
cancellazione di più Sense accettano quindi le normali catene `rdf:rest`, mentre
le celle realmente condivise continuano a produrre un conflitto e rollback.
La suite repository copre ora anche promozione e cancellazione delle Form,
precondizioni stale, round-trip metadata e annotazioni native, mapping tipato
dei figli ricchi, relazioni VarTrans Sense e lifecycle completo Sense/Synset.
Il bootstrap esegue ora creazione e import dello schema `LexOWordnets` prima di
qualsiasi mutazione di bootstrap lessicale o testuale: errori WordNet di
repository, checksum, RDF/XML o validazione schema lasciano quindi invariati
`LexOLexica` e `LexOTexts` nel tentativo di startup corrente.
La collezione del registro WordNet viene inoltre ordinata per IRI crescente
prima di applicare offset e limite, come le altre collezioni CRUD.
Form, Sense e Relation verificano ora anche ownership e struttura completa
degli endpoint, non soltanto `rdf:type`: risorse tipizzate ma orfane o Synset
malformati vengono rifiutati senza scritture parziali. Nei Sense PATCH,
`subcategorizationIds: []` resta l'unico modo per svuotare i link; `null` è
respinto e l'omissione continua a lasciare il valore invariato.
Lo stesso controllo strutturale è applicato dalla lettura e dal batch del
workflow Entry e ai riferimenti `sourceSenseId` delle definizioni Synset: una
risorsa soltanto tipizzata ma non posseduta non può essere letta o mutata da
questi percorsi, e gli errori di creazione restano transazionali.
La readiness `/service/health/ready` include ora anche il probe del repository
`LexOWordnets`, lo espone come `wordnetRepository` e restituisce `UP` soltanto
quando bootstrap e tutti e tre i repository sono disponibili.

Il contratto comune dei metadati RDF è riusato per ogni risorsa principale e
ausiliaria. `MetadataPolicy` protegge ora l'intero namespace GWA e i predicati
del workflow LexO; `notes`, `wordnetStatus` e `confidenceScore` gestiscono
direttamente le annotazioni WordNet. Il workflow `working`/`completed`/`revised`
è indipendente da `wn:status` e usa soltanto il manager WordNet dedicato. La
documentazione normativa è in `docs/wordnet-services.md`; `AGENTS.md`, la guida
bootstrap, `docs/lexicon-services.md`, Compose e `CHANGELOG.md` sono aggiornati.

Verifica eseguita:

- suite WordNet mirata: 33 test superati;
- test mirati di health e routing WordNet: 5 test superati;
- `mvn -o test`: 310 test unitari/repository superati, nessun failure, errore o
  skip;
- E2E WordNet mirati: 2 test superati contro GraphDB remoto dedicato;
- `mvn -o verify`: 310 test unitari/repository e 18 end-to-end superati,
  nessun failure, errore o skip; build e WAR riusciti;
- checksum del Turtle nel repository identico al file allegato; `git diff
  --check` senza errori.

Gli stack trace dei percorsi d'errore simulati, i warning Maven sui metadata e
il warning Lucene `MMapDirectory` con il JDK moderno restano attesi. I repository
e il filesystem E2E temporanei sono stati eliminati dopo la verifica. Rimane
valida l'assunzione di un solo writer LexO-server attivo per la creazione
globalmente univoca del `wordnetId`, come documentato.

Aggiornato al 27 ottobre 2026 con il supporto `TOKEN`/`LEMMA`/`POS` nei servizi
di co-occorrenza ed estrazione collocati. Sul branch `master`, allineato a
`origin/master` prima delle modifiche, `POST /texts/search/cooccurrences` e
`POST /texts/collocations/extract` accettano ora `nodeField` e
`collocateField` indipendenti; entrambi mantengono `TOKEN` come default
retrocompatibile. Il primo endpoint può quindi cercare, per esempio, un nodo
per lemma e un collocato per POS, e restituisce per ogni posizione la forma
superficiale più lemma/POS disponibili. Il secondo seleziona il nodo e
raggruppa/calcola frequenze e metriche sull'attributo scelto; ogni gruppo espone
anche le varianti ordinate di superficie, lemma e POS e valorizza i campi
singolari soltanto quando non sono ambigui. I token privi dell'annotazione
selezionata non generano corrispondenze o gruppi artificiali.

L'implementazione riusa i campi lemma e la token map canonica già presenti
nello snapshot Lucene; perciò non modifica lo schema indice 3 e non richiede un
nuovo rebuild oltre a quello già necessario per indici anteriori. I field non
ammessi producono codici macchina `INVALID_NODE_FIELD` o
`INVALID_COLLOCATE_FIELD`. Swagger, architettura, procedura test e
`CHANGELOG.md` sono aggiornati; `README.md` è rimasto invariato. Tre nuovi test
coprono combinazione lemma→POS, estrazione e metriche raggruppate per POS,
annotazioni restituite e validazione. I test mirati
`LuceneCorpusSearchServiceTest,TextsTest` hanno superato 15 casi; `mvn -o test`
ha superato tutti i 288 test unitari/repository senza failure, errori o skip.
Gli stack trace dei percorsi d'errore simulati e il warning `MMapDirectory` del
JDK moderno restano attesi. Non sono stati eseguiti deploy o end-to-end; il
prossimo passo raccomandato è provare entrambi i payload su un corpus CoNLL-U o
JSON annotato in un deployment isolato e verificare anche le combinazioni con
annotazioni parziali.

Aggiornato al 26 ottobre 2026 con la ricerca full-text per lemma, la validazione
preventiva e la correzione completa del case-insensitive Lucene.
`POST /texts/search/fulltext` distingue `searchField=TOKEN` (default compatibile)
da `LEMMA`; i lemma non vuoti e diversi da `_` sono indicizzati mantenendo
posizione e offset del token originale, quindi le risposte lemma espongono forma
flessa, offset NIF e KWIC canonici. I quattro campi TOKEN/LEMMA applicano NFC;
le varianti surface preservano il case e le varianti normalized usano il
`LowerCaseFilter` di Lucene.

TERM, PHRASE, BOOLEAN, PREFIX, WILDCARD e FUZZY condividono gli stessi parser e
limiti. La query BOOLEAN grezza è passata al parser senza lowercase o regex
globali: `AND`, `OR` e `NOT` restano operatori ufficiali maiuscoli, mentre
`and`, `or` e `not` minuscoli sono termini ordinari. Prefix, wildcard, fuzzy e
regex usano `Analyzer.normalize`; frasi, parentesi, escape e diagnostici
mantengono la query originale. `caseSensitive=true` seleziona realmente i campi
case-preserving.

La copertura lemma è calcolata dai `nif:Word`/`nif:lemma`, non dalla presenza di
un file CoNLL-U, ed è esposta come `lemmaSearchAvailable`, `lemmaTokenCount` e
`lemmaCoverage` da `GET /texts`, `GET /texts/{fileId}` e dai membri inclusi in
`GET /text-folders?includeTexts=true`. Una selezione senza lemmi fallisce con
`LEMMA_SEARCH_UNAVAILABLE`; una selezione mista fallisce per default con
`INCOMPLETE_LEMMA_COVERAGE`. Con
`requireCompleteLemmaCoverage=false` la risposta include conteggi e liste dei
context ricercati/esclusi, perciò il risultato parziale non è silenzioso.

Il nuovo `POST /texts/search/fulltext/validate` usa lo stesso codice di parsing
senza eseguire la query e restituisce `valid`, query normalizzata oppure codice,
messaggio e posizione parser disponibile. Lo schema dell'indice è passato a
`3`; ogni snapshot registra la versione e `verify` segnala
`indexSchemaMismatch`. Una lemma search su un vecchio documento non restituisce
un falso zero ma `LEMMA_INDEX_OUTDATED`. Reindex e rebuild recuperano i lemma
dal NIF persistito e ricreano i quattro campi posizionali.

Swagger, architettura, procedura test e `CHANGELOG.md` sono aggiornati;
`README.md` è rimasto invariato. Il filtro opzionale `folderId` non è stato
incluso in questa prima versione, come consentito dalla specifica non
bloccante: il frontend può continuare a risolvere la cartella in `contextIRIs`.
Prima del deploy su un indice esistente eseguire `POST /texts/index/verify`,
`POST /texts/index/rebuild` e `POST /texts/index/verify?deep=true`.

La suite Lucene mirata ha superato 10 test. `mvn -o test` e `mvn -o verify`
hanno superato 285 test unitari/repository senza failure, errori o skip e
prodotto `target/LexO-server.war`; i 16 end-to-end sono compilati ma skipped
perché non era configurato un deployment Tomcat/GraphDB con filesystem e indice
dedicati. Restano i warning ambientali noti sui metadata Maven e su
`MMapDirectory` con il JDK moderno; gli stack trace dei percorsi d'errore sono
attesi dai relativi test. Non è stato eseguito alcun deploy; le modifiche
case-insensitive sono raccolte in un commit dedicato su `master`. Il prossimo
passo raccomandato è ridistribuire il WAR in un ambiente isolato,
ricostruire l'indice schema 3 e lanciare i workflow E2E, incluso UC-03 CoNLL-U.

Aggiornato al 23 ottobre 2026 con l'organizzazione gerarchica opzionale dei
testi. Il branch `master` espone ora dieci operazioni sotto `/text-folders` per
creare, leggere, aggiornare, spostare ed eliminare cartelle vuote, assegnare o
rimuovere testi, eseguire move bulk atomici e calcolare i testi unfiled. Le
cartelle hanno UUID server-side, profondità non limitata e cicli vietati; ogni
testo può appartenere a una sola cartella. Il servizio Swagger usa il gruppo
`Text Organization` e gli errori di validazione hanno codici macchina stabili.

Il vocabolario allegato è stato conservato semanticamente ma convertito dalla
sintassi Turtle ricevuta a RDF/XML valido, come richiesto dal contratto di
bootstrap. `GraphDbBootstrap` lo importa idempotentemente nel graph schema
`https://lexo.ilc.cnr.it/graphs/text-organization/schema` del repository
`LexOTexts`, con checksum e validazione di `txo:Folder`; le istanze restano nel
graph separato `https://lexo.ilc.cnr.it/graphs/text-organization`, che non viene
mai cancellato dal bootstrap. Il runtime persiste soltanto
`txo:parentFolder` e `txo:containsText`, mai inverse, default graph o triple nei
graph NIF/corpus. NIF, corpora e indice Lucene restano invariati.

La cancellazione di un testo rimuove ora anche la membership organizzativa. Se
una fase successiva del delete coordinato fallisce, la compensazione ripristina
sia il graph/record NIF sia la precedente membership; il bulk delete eredita lo
stesso comportamento. Sono stati aggiunti test bootstrap, repository RDF,
manager e contratto REST/Swagger, oltre al workflow remoto UC-05 con cleanup in
`finally`. La suite completa `mvn -o test` ha superato 280 test senza failure,
errori o test saltati. `mvn -o verify` ha inoltre prodotto correttamente
`target/LexO-server.war`; i 16 end-to-end sono risultati skipped perché non era
configurato un deployment Tomcat/GraphDB con directory Lucene/filesystem
dedicate. Il passo successivo raccomandato è ridistribuire il WAR in
quell'ambiente ed eseguire il nuovo UC-05 con le proprietà descritte in
`docs/text-services-tests.md`. Non è stato eseguito alcun deploy.
Attività CPP del 15 ottobre 2026 sul branch `cpp`, creato dal `master`
aggiornato `d4429e3` con fetch e fast-forward sicuro. Il commit `b03e398`
introduce le ontologie CPP 0.2.1 e CollScore 1.2.0 senza alterarne i byte,
il bootstrap misto Turtle/RDF/XML e il report amministrativo compatibile.

Implementate le sei API `/service/cpp/runs` (POST/lista/dettaglio/PATCH/DELETE)
e `/service/cpp/runs/export`, con DTO Swagger, JSON rigoroso, normalizzazione
condivisa con Lucene, 18 misure, mapper CPP, graph dedicato e transazioni
LEXICON. Idempotenza autore/chiave e unicità delle associazioni sono protette
da lock condiviso nella JVM. L'export Turtle appiattisce i graph, conserva
letterali e score esistenti e usa temporanei con cleanup anche su errori o
disconnessione. Non esegue ricerche e non modifica FrAC, indice o TEXT.
Documentazione completa: `docs/cpp-run-services.md`.

Verifica completata: 302 test unitari/repository passati senza errori o skip,
sia con JDK 21 sia sulla JVM Java 8 `1.8.0_504` (Surefire `-Djvm=...`).
`mvn -o verify -Dit.test=CppRunsIT` ha generato `target/LexO-server.war` e
superato la verifica: il solo test E2E CPP è skipped per assenza di opt-in e
configurazione Tomcat/GraphDB dedicata, quindi non è un collaudo remoto.
`git diff --check` passato. Restano warning non bloccanti del modello Maven e
delle policy checksum di repository legacy, API deprecated/unchecked e
Lucene MMapDirectory sul JDK moderno. Nessun deploy. README.md invariato.
Maven disponibile in `/opt/homebrew/bin/mvn`; il percorso storico NetBeans
12.2 non è presente.

Limiti noti: configurare un solo writer CPP per repository (nessun lock
distribuito); snapshot e parametri sono provenienza dichiarata, non prova di
riesecuzione storica. FrAC/P-Plan/PROV-O non sono schemi locali completi e non
vengono scaricati da owl:imports; i vincoli sono validati nel servizio. Restano
fuori scope migrazione dei 15 score FrAC legacy e persistenza di
RAW_FREQUENCY/NPMI/Z_SCORE. PATCH conserva la vista corrente e non uno storico
di versioni. Prossimi passi: collaudo E2E isolato e, se richiesto, gestione
multi-writer e migrazione score in attività separate.

Aggiornato al 15 ottobre 2026: il branch `lucene`, già pubblicato e verificato,
è stato integrato in `master` con fast-forward fino al commit `9eac18f`. Non si
sono verificati conflitti e non è stata riscritta la storia. Dopo
l'integrazione la suite completa è stata rieseguita su `master`; non è stato
effettuato alcun deploy. Verificato che `lucene` fosse interamente contenuto in
`master`, il branch dedicato è stato eliminato sia localmente sia da `origin`;
il lavoro prosegue sul solo branch `master`.

Aggiornato al 7 ottobre 2026: i dieci nuovi endpoint di ricerca full-text,
KWIC, frequenze, co-occorrenze, collocazioni e amministrazione dell'indice
Lucene sono ora pubblicati in Swagger con il tag separato `Text Search`. Gli
endpoint preesistenti restano nel gruppo `Text Corpus NIF`; path REST e
contratti non sono cambiati. `TextsTest` verifica esplicitamente il tag di tutti
i dieci endpoint nel modello Swagger generato e il mantenimento del gruppo
storico. La suite completa `mvn test` ha superato 272 test senza failure,
errori o test saltati; restano i warning ambientali Maven/Lucene già noti.

Aggiornato al 2 ottobre 2026 dopo il refactoring completo NIF + Apache Lucene
standalone dei servizi `Text Corpus NIF`. Il lavoro è sul branch dedicato
`lucene`, dal quale è stato successivamente integrato in `master`. La consegna
completa è consolidata nel commit `9eac18f`, inizialmente pubblicato su
`origin/lucene` e poi integrato in `master`; il branch dedicato è stato
successivamente eliminato. Non è stato eseguito alcun deploy.

TXT e contenuti JSON sono ora decodificati in UTF-8 stretto, privati di un BOM
iniziale, normalizzati CRLF/CR → LF e NFC. La segmentazione unica applica
`CONLLU > ANNOTATED_IMPORT > LUCENE_STANDARD`; gli stessi span generano
`nif:Word`, `nif:Sentence`, positions/offsets Lucene e fingerprint SHA-256 RDF e
indice. Gli span pubblici restano code point Unicode, quelli interni Lucene sono
UTF-16. I NIF legacy vengono reindicizzati dai word/sentence persistiti come
`PERSISTED_NIF`, senza ritokenizzazione.

L'indice Lucene 8.11.3 usa `FSDirectory`, `IndexWriter`, `SearcherManager`,
positions, offsets e term vector sui campi surface/lowercase. Sono disponibili
full-text occurrence search, resize KWIC stateless, frequenze, co-occorrenze,
collocati e tutte le metriche richieste; occurrence, frequenze e coppie leggono
le positions/term vector Lucene. Import e delete usano compensazioni esplicite
tra Lucene e RDF. Status, verify, reindex e safe rebuild con `CheckIndex`, swap
e rollback completano la gestione operativa. La ricerca non usa connector
GraphDB o funzioni SPARQL full-text; l'arricchimento usa `VALUES` SPARQL 1.1 e
la persistenza FrAC è un'azione separata.

La suite completa `mvn test` ha superato 272 test senza failure, errori o test
saltati. `mvn -DskipTests package` ha prodotto con successo
`target/LexO-server.war`. Sono coperti canonicalizzazione/Unicode, Markdown,
CoNLL-U, JSON annotato, query Lucene, sentence boundary, KWIC, co-occorrenze,
frequenze, metriche, failure RDF/Lucene, reindex legacy e safe rebuild. I nuovi
controlli in `TextServicesIT` compilano e verificano import → ricerca → delete,
ma gli end-to-end non sono stati eseguiti perché richiedono un deployment
Tomcat/GraphDB e directory Lucene dedicate. Restano warning ambientali non
bloccanti sul metadata repository Maven con certificato java.net scaduto, sulle
API deprecated/unchecked preesistenti e su `MMapDirectory` con il JDK moderno.

Prima di usare l'indice su dati esistenti: configurare
`lexo.lucene.index.path` e `lexo.lucene.rebuild.temp.dir`, distribuire il WAR,
eseguire `POST /texts/index/verify`, `POST /texts/index/rebuild` e infine
`POST /texts/index/verify?deep=true`. Il prossimo passo raccomandato è il
collaudo `mvn verify` contro repository e filesystem esclusivamente di test.
Architettura, configurazione, migrazione e checklist completa degli endpoint
sono in `docs/text-lucene-architecture.md`; la procedura test è aggiornata in
`docs/text-services-tests.md`.

Aggiornato al 1 ottobre 2026 con la documentazione sintetica dei servizi ECD
legacy dichiarati in `ECDCreation`, `ECDData`, `ECDDeletion` ed `ECDUpdate`.
`docs/ecd-services.md` riporta metodo, endpoint, funzione, parametri essenziali
e comportamento dei 24 servizi operativi, separando esplicitamente le sei rotte
placeholder che restituiscono ancora `null`. Non sono stati modificati codice
Java o contratti REST. Per questa modifica esclusivamente documentale non è
stata eseguita la suite Maven; la verifica applicabile è `git diff --check`.

Aggiornato all'8 settembre 2026 dopo l'implementazione di
`GET /service/attestations/export/web-annotation`. L'endpoint esporta i graph
documentali delle attestazioni con tre selettori Unicode e Body multipli;
FrAC e NIF restano rispettivamente in `LexOLexica` e `LexOTexts`. Il contesto
si risolve dal locus, anche quando `observedIn` identifica un corpus.
`includeMetadata=true` riusa la mappa metadati esistente e conserva creator e
date in `lexoProvenance`, entrambi JSON literals in JSON-LD 1.1. Duplicati
compatibili vengono unificati; dati discordanti, identificatori strutturali
non IRI e canonico assente producono HTTP 422 senza risposta parziale.
L'export non scrive nei repository e non scarica URL esterni.

La suite completa, eseguita con il Maven di NetBeans 12.2 in modalità offline
(`mvn -o test`), ha superato 252 test senza failure, errori o test saltati.
Il controllo separato `python3 scripts/verify-web-annotation-jsonld.py` è passato
con RDFLib 6.2.0, verificando RDF Web Annotation e i due `rdf:JSON` generati
realmente dai test Java. Il parser Java già incluso supporta JSON-LD 1.0:
nessuna dipendenza del WAR è stata cambiata per il controllo 1.1. La prima
esecuzione Maven non offline ha mostrato warning sui tracking file `~/.m2`
non scrivibili nel sandbox; le successive verifiche offline sono passate.
Restano i messaggi preesistenti del compilatore su API deprecate/unchecked.

È stato aggiunto e compilato `AttestationsExportIT`, ma il collaudo REST contro
Tomcat/GraphDB non è stato eseguito: occorre distribuire questa build su un
deployment con due repository dedicati, seguendo
`docs/attestation-web-annotation-export.md`. L'export è attualmente preparato e
serializzato in memoria: occupazione proporzionale al risultato e ai testi
canonici conservati per il confronto dei duplicati; nessuno snapshot distribuito
tra i due repository. Il prossimo passo è il collaudo end-to-end dedicato.
Consegna tramite commit dedicato su `master`: `Export attestations as Web Annotation JSON-LD`.
Non è stato eseguito alcun deploy; le microguide manuali preesistenti restano
escluse dal commit dell’export.

Aggiornato al 3 settembre 2026: gli import TXT conservano ora esattamente il
corpo UTF-8 decodificato, senza trim, collasso del whitespace, conversione dei
line ending, rimozione del BOM o normalizzazione Unicode. L'eventuale front
matter continua a essere interpretato e rimosso dal canonico; gli offset del
corpo ripartono quindi da zero e restano code point di `nif:isString`. Il
`text.content` dei JSON applica la stessa conservazione esatta, senza
interpretare come front matter un eventuale blocco `---`; CommonMark non cambia.
I test mirati e la suite Maven completa di 216 test sono passati senza failure,
errori o test saltati; gli end-to-end non sono stati eseguiti in questa attività
perché richiedono il redeploy della build sul Tomcat di test.

Aggiornato al 2 settembre 2026 dopo la separazione della normalizzazione plain
text da quella CommonMark. TXT e `text.content` dei JSON conservano ora tutti i
ritorni a capo, dopo la conversione CRLF/CR in LF, mentre il whitespace restante
continua a essere normalizzato per riga. Il CommonMark mantiene la semantica
precedente: i soft break interni al paragrafo diventano spazi. Paragrafi,
segmentazione e NIF sono costruiti direttamente sulla nuova stringa canonica;
gli offset restano code point Unicode di `nif:isString`, non posizioni nel file
fisico originale. I test mirati del parser, del writer NIF, del parser JSON e di
CoNLL-U e la suite Maven completa di 214 test sono passati senza errori o test
saltati. Il collaudo contro Tomcat e GraphDB locali ha inoltre superato tutti i
14 end-to-end (10 scenari REST e 4 workflow REST/SPARQL/filesystem), compresi i
controlli espliciti sul canonico TXT/JSON con LF e sul soft break CommonMark.

Aggiornato al 31 agosto 2026 dopo il primo avvio completo dello stack Compose.
È stato corretto `LexOProperties.load()`, che calcolava le sostituzioni da
variabili `LEXO_*` e proprietà JVM ma non assegnava il risultato alla
configurazione effettiva; per questo il container tentava erroneamente
`localhost:7200` invece di `http://graphdb:7200`. Un nuovo test copre il
caricamento reale delle proprietà JVM. La build Docker ha superato 212 test e
lo stack locale è ora sano: GraphDB e LexO risultano `healthy`, il bootstrap ha
creato `LexOLexica` e `LexOTexts`, importato 13 risorse di schema e creato 9
indici. `/service/health/ready` restituisce HTTP 200/`UP`, Swagger restituisce
HTTP 200 e l'API GraphDB elenca entrambi i repository in stato `RUNNING`. I
volumi GraphDB e LexO sono stati preservati durante la sostituzione del solo
container applicativo.

Aggiornato al 28 agosto 2026 dopo il collaudo della build sul Docker Desktop
locale, con Docker Engine 20.10.7. La build multi-stage ha installato
esplicitamente l'artefatto vendorizzato `OntoApi` nel repository Maven del
builder, superando la limitazione di `dependency:go-offline`; il test del
timestamp accetta ora sia l'offset numerico sia la forma UTC `Z`, così la suite
non dipende più dal fuso orario della macchina. L'immagine
`lexo-server:docker-test` è stata creata correttamente dopo 211 test senza
errori o test saltati. Il runtime Compose è stato poi collaudato il 31 agosto;
restano da verificare end-to-end gli script backup/restore/update.

Aggiornato al 27 agosto 2026 dopo l'introduzione della distribuzione Docker.
`compose.yaml` avvia Tomcat 9/LexO-server e GraphDB 10.8 come servizi separati,
con health check, bootstrap ritentabile, utenti non root e volumi persistenti
per repository, file applicativi e log. La configurazione impacchettata può ora
essere sovrascritta con un file esterno, variabili `LEXO_*` o proprietà JVM;
gli storage testuali e legacy non sono più vincolati alla directory di lavoro.
Sono disponibili backup/restore coordinati e installazione di un nuovo WAR
tramite immagine versionata e sostituzione del solo container LexO. La suite
Maven completa ha superato 211 test senza errori o test saltati; la sintassi
degli script, `git diff --check` e la risoluzione Compose sono state verificate.

Aggiornato al 27 agosto 2026 dopo la correzione del client end-to-end per la
cancellazione multipla dei testi. Il client Jersey dei test abilita ora
esplicitamente le richieste HTTP con entity, consentendo allo scenario
`DELETE /texts/bulk` di inviare il payload JSON e verificare realmente il job
asincrono, i due esiti `DELETED` e l'esito idempotente `NOT_FOUND`. La verifica
completa contro Tomcat e GraphDB locali ha superato 205 test unitari/repository
e tutti i 13 end-to-end senza errori o test saltati. Il cleanup ha preservato i
quattro testi preesistenti, riportato `LexOTexts` a 24.211 triple e non ha
lasciato artefatti temporanei nel filesystem. Non restano interventi relativi
a questo difetto del test.

Aggiornato al 27 agosto 2026 dopo la ristrutturazione del logging. Il WAR usa
ora SLF4J 2 con un solo backend Log4j 2, output JSON, rotazione giornaliera e a
100 MB, retention di 30 giorni e cap archivio di 1 GB configurabili. Il filtro
HTTP gestisce `X-Request-ID`, stato, durata, versione e attore in MDC; il
lifecycle applicativo e il bootstrap GraphDB sono separati dal filtro. I job
asincroni di Testo/NIF e Conversion conservano il contesto e aggiungono
`fileId`/`bulkId`. Metadata, Testo/NIF, Attestations, Lexica e Conversion usano
direttamente SLF4J; gli altri servizi, destinati alla riscrittura, passano
temporaneamente per `log4j-1.2-api` senza richiedere modifiche usa-e-getta. Gli
86 log storici sono stati rimossi dall'indice Git ma lasciati sul filesystem;
`logs/`, `data/` e gli artefatti IDE sono ignorati. Gli 8 test mirati del
logging e la suite Maven completa di 205 test sono passati senza errori o test
saltati; gli end-to-end REST non sono stati eseguiti perché richiedono GraphDB
e Tomcat dedicati. Il packaging pulito del WAR è passato e contiene un solo
provider, la sola configurazione `log4j2.xml` e il bridge legacy previsto. Il
prossimo passo raccomandato è rimuovere il bridge Log4j 1 quando scomparirà
l'ultimo servizio legacy; non migrare isolatamente i servizi già pianificati
per la sostituzione.

Aggiornato al 25 agosto 2026 dopo l'introduzione della cancellazione multipla
asincrona dei testi. `DELETE /texts/bulk` valida una lista non vuota e senza
duplicati, restituisce HTTP 202 con un `bulkId` e processa sequenzialmente ogni
testo in background tramite la stessa implementazione di
`DELETE /texts/{fileId}`. `GET /texts/deletions/{bulkId}/status` espone stato,
contatori ed esito ordinato di ogni elemento. Gli errori sono indipendenti: un
fallimento tecnico non interrompe gli elementi successivi, mentre `NOT_FOUND` è
considerato un esito idempotente completato. Il limite predefinito è 100 ed è
configurabile con `lexo.text.maxBulkDeleteFiles`; i job sono mantenuti in
memoria e non sopravvivono al riavvio. Sono presenti test unitari del manager e
del contratto REST e uno scenario end-to-end opzionale contro un deployment
isolato. La suite Maven completa ha eseguito 197 test senza errori o test
saltati; lo scenario end-to-end REST non è stato eseguito perché richiede
GraphDB e Tomcat dedicati.

Aggiornato al 25 agosto 2026 dopo l'estensione di `POST /texts/bulk` ai file
JSON con schema chiuso. Un batch può ora contenere TXT, CommonMark e JSON con
una sola lingua ISO: il `corpusId` query continua ad applicarsi ai soli file
testuali ed è vietato nei batch esclusivamente JSON, mentre ogni JSON può usare
il proprio `metadata.corpus`. Il contenuto `text.content` viene convertito come
TXT senza front matter e l'originale JSON viene conservato. Le attestazioni
valide sono importate con creator `imported`, `rdf:value`, `frac:gloss`, metadata
comuni e frequency nel graph attestazioni del documento; il locus resta nel
graph NIF. Gli observable sono risolti con tipo esatto nel graph ISO della
lingua o nel graph fisso dei lexical concept. Ogni attestazione ha una
transazione indipendente: gli elementi non validi sono riportati dal polling in
`unsavedAttestations` e non annullano testo o attestazioni valide. Lo schema o un
corpus non valido rifiutano invece atomicamente il batch in ammissione. La
compilazione degli end-to-end, 81 test mirati e la suite Maven completa di 192
test sono passati senza errori o test saltati. Gli end-to-end REST aggiunti non
sono stati eseguiti perché richiedono un deployment GraphDB/Tomcat isolato.

Aggiornato al 21 agosto 2026 dopo il rafforzamento di
`DELETE /texts/{fileId}`. La cancellazione continua a rimuovere record e graph
NIF, appartenenza al corpus, file persistiti e graph documentali di attestazioni
e annotazioni. Prima di svuotare questi ultimi, ora identifica nel graph del
testo sia le risorse `frac:Attestation` tipizzate sia gli oggetti dei link
`frac:attestation`, quindi elimina atomicamente da `LexOLexica` ogni tripla che
le usa come soggetto o oggetto, anche se collocata per errore in un altro named
graph. Per ogni link `frac:attestation` così rimosso da un altro graph
documentale valido, la frequency esistente dell'observable viene ricalcolata
sulle attestazioni tipizzate residue; quando il conteggio è zero vengono rimossi
anche il link `frac:frequency` e la relativa risorsa. La sincronizzazione è ora
centralizzata in `AttestationFrequencySupport` e condivisa con le normali
mutazioni delle attestazioni. Attestazioni e dati residui degli altri testi
restano invariati. I test mirati eseguono 49 casi senza errori; la suite completa
del 21 agosto 2026 ha eseguito 178 test senza errori o test saltati. Gli
end-to-end REST non sono stati eseguiti perché richiedono un deployment
GraphDB/Tomcat dedicato. Restano i warning ambientali noti sui tracking file
Maven nel sandbox e sul binding SLF4J.

Rimane valido il lavoro del 14 agosto 2026 dopo l'ottimizzazione di
`POST /attestations/{fileId}`. Le richieste comuni senza filtri complessi,
incluso il vincolo query opzionale `observable`, eseguono ora conteggio,
ordinamento, `LIMIT` e `OFFSET` direttamente in GraphDB. Le proprietà FRAC,
le frequenze e i loci NIF dei soli risultati della pagina vengono caricati in
batch per named graph, eliminando la scansione completa e le letture RDF per
singolo campo. I filtri complessi conservano la semantica precedente e usano
comunque l'arricchimento batch dopo la selezione. Il vincolo `observable`
seleziona direttamente la relazione FRAC nel graph documentale anche quando è
combinato in `AND` con autore, tipo e filtro JSON. I test repository verificano
selezione, composizione, `totalHits`, paginazione server-side, metadata,
frequenze, NIF e attestazioni orfane. La suite completa del 14 agosto 2026 ha
eseguito 178 test senza errori o test saltati;
restano soltanto i warning ambientali già noti sui tracking file Maven nel
sandbox e sul binding SLF4J. Rimane valido il lavoro del 9 agosto 2026 dopo la
revisione di
`PATCH /attestations/{fileId}/locus`: il servizio ricollega ora una singola
attestazione senza modificare fisicamente il locus precedente. Riusa una
destinazione compatibile, di sistema o LexO, oppure crea un nuovo locus marcato
LexO quando la destinazione manca. Conserva sempre i loci di sistema e quelli
ancora condivisi; elimina il precedente soltanto quando è LexO-owned e rimasto
orfano nell'intera famiglia dei graph di attestazione. I test repository
dedicati coprono tutte queste combinazioni e gli offset Unicode. La validazione
completa `mvn test` del 9 agosto 2026 ha eseguito 176 test senza errori o test
saltati. Rimane valido
il lavoro del 7 agosto 2026 relativo a
`GET /lexica/lexicalConcept`, che restituisce il modello completo di un lexical
concept dal graph fisso: label e definizioni multilingui, entry e sense risolti
nei soli graph ISO con fallback di label, concept set, gerarchie SKOS dirette e
transitive distinte e metadata comuni. I metadata accettano
`addValues` e `removeValues` per modificare valori RDF esatti senza reinviare
l'intera proprietà. Preferred label, alternative label, hidden label e
definition hanno coppie add/remove indipendenti e idempotenti; la rimozione non
può lasciare un concept privo di preferred label. Per i sense il PATCH accetta
`addSenses` per aggiungere link senza sostituire quelli esistenti e
`removeSenseIds` per rimuovere soltanto i link indicati; entrambe le operazioni
sono idempotenti e possono essere combinate. La modalità `senses` continua a
sostituire l'intera collezione ed è mutuamente esclusiva con le modalità
incrementali. Ogni senso aggiunto o sostitutivo è identificato da `senseId` e
`language`, viene validato esclusivamente nel graph lessicale ISO della lingua
dichiarata e non viene copiato nel graph dei concept. Creazione e modifica
scrivono la relazione `ontolex:lexicalizedSense` nel graph fisso dei concept,
mentre il PATCH ripulisce l'inverso errato per ogni modifica dei sensi. Il lavoro
include inoltre i servizi atomici di modifica di
lexical entry e lexical concept, che cambiano soltanto le proprietà semantiche
di propria competenza e lasciano i metadata al CRUD comune `/metadata`. I nuovi
payload RDF di lexical entry, lexical concept, CRUD metadata e attestazioni
evitano inoltre l'ambiguità MOXy tra il campo `type` (`literal`/`iri`) e il
discriminatore di classe EclipseLink; i contratti JSON restano invariati. I nuovi
CRUD lessicali e i servizi di attestazione adottano esclusivamente i named graph
di categoria. Gli
observable sono risolti nel graph ISO della lingua per entry, form e sense,
oppure nel graph fisso dei lexical concept; default graph, graph legacy e
collocazioni di categoria errate non vengono accettati. La creazione delle entry
scrive `ontolex:sense` e lascia la relazione inversa `ontolex:isSenseOf`
all'inferenza; le risposte delle attestazioni risolvono tipi e label dallo stesso
graph effettivo. Il CRUD comune `/metadata`
ammette anche `lexicalSense` e `form`, risolti nel graph lessicale della lingua.
Il lavoro è direttamente sul branch `master`, accanto agli
altri servizi incrementali in `Lexicon.java`. Il nuovo endpoint usa il
connettore GraphDB esistente verso `LexOLexica` e isola letture e scritture nel
graph fisso `https://lexo.ilc.cnr.it/graphs/lexical/lexicalConcept`. Il POM
risolve inoltre l'artefatto Maven
non pubblico `klab.ilc.cnr.it:OntoApi:1.0` dal repository file-based versionato
sotto `vendor/maven`, senza richiedere una preventiva installazione locale.
Questo documento descrive lo stato osservato del repository; prima di iniziare
nuovo lavoro verificare sempre `git status`, il branch remoto e la
configurazione effettivamente usata dall'installazione.

## Scopo del progetto

LexO-server è un backend REST per creare, consultare, aggiornare, convertire ed
esportare risorse linguistiche Linked Data. Gestisce in particolare lessici
OntoLex-Lemon, dizionari Lexicog, risorse SKOS, ECD, testi e corpora rappresentati
in NIF, attestazioni FRAC e Web Annotation.

Il progetto produce un WAR da distribuire su Tomcat. L'interfaccia Swagger
incorporata documenta i servizi e costituisce il punto di ingresso per client e
future interfacce web.

## Architettura e tecnologie

- Java con compatibilità bytecode configurata a Java 8 (`source` e `target` 1.8).
- Maven, packaging `war`, nome finale `LexO-server.war`.
- Jersey/JAX-RS 2 (`javax.*`) per i servizi REST e multipart.
- Apache Tomcat 9; context path `/LexO-server`, API sotto `/service/*`.
- Swagger 1.6 e Swagger UI inclusa nel WAR.
- Eclipse RDF4J 3.7.6 come client remoto di GraphDB Free.
- Jackson per JSON; JUnit 5 e AssertJ per i test.
- GraphDB Free su `http://localhost:7200`, senza GraphDB embedded.
- Nessuna persistenza MySQL/Hibernate/Spring: Maven ne vieta il reinserimento
  tramite `maven-enforcer-plugin`.

La struttura applicativa segue principalmente questo flusso:

1. le classi in `service` espongono gli endpoint Jersey;
2. i manager applicano regole di dominio e orchestrano conversione/persistenza;
3. `GraphDbUtil` e `RDFQueryUtil` selezionano a runtime il repository tramite
   `RepositoryTarget.LEXICON` o `RepositoryTarget.TEXT`;
4. le classi `sparql` contengono query e template SPARQL;
5. i DTO di input/output sono sotto `service/data`.

## Persistenza e named graph

LexO-server usa sempre due repository GraphDB configurati in
`src/main/resources/lexo-server.properties`:

- `LexOLexica`: dati lessicali, schema, attestazioni e annotazioni;
- `LexOTexts`: NIF di testi e corpora e record operativi testuali.

Named graph principali di `LexOLexica`:

- `https://lexo.ilc.cnr.it/graphs/lexical/lexica` per i dati lessicali;
- `https://lexo.ilc.cnr.it/graphs/lexical/lexicalConcept` per i nuovi lexical
  concepts e concept sets;
- `https://lexo.ilc.cnr.it/graphs/lexical/attestations/documents/{fileId}` per
  le attestazioni di un testo;
- `https://lexo.ilc.cnr.it/graphs/lexical/annotations/documents/{fileId}` per
  le annotazioni di un testo;
- `https://lexo.ilc.cnr.it/graphs/lexical/schema` per ontologie e vocabolari;
- `https://lexo.ilc.cnr.it/graphs/bootstrap` per checksum e stato bootstrap.

`LexOTexts` usa un graph per documento, un graph per corpus e il graph interno
`https://lexo.ilc.cnr.it/graphs/nif/records`. Gli originali caricati e gli
eventuali CoNLL-U restano nel filesystem sotto `data/texts` (o sotto il path
indicato da `-Dlexo.text.storage.dir=...`); testo canonico, NIF, metadati e
appartenenza ai corpora sono persistiti in GraphDB.

## Struttura principale delle cartelle

```text
.
├── docs/                         documentazione operativa e test
├── src/main/java/it/cnr/ilc/lexo/
│   ├── bootstrap/                bootstrap idempotente GraphDB Free
│   ├── manager/                  logica di dominio e conversione
│   │   └── text/                 import, NIF, corpus e catalogo testi
│   ├── service/                  endpoint REST Jersey e DTO in service/data
│   ├── sparql/                   query e template SPARQL
│   ├── servlet/                  inizializzazione Swagger
│   └── util/                     utility RDF, named graph e query
├── src/main/resources/
│   ├── bootstrap/repositories/   template Turtle dei repository GraphDB
│   ├── iso639/                    lista dei codici lingua ammessi negli upload
│   ├── bootstrap/schema/         RDF/OWL e manifest di import
│   ├── bootstrap/indexes/        query e manifest degli indici Lucene
│   └── lexo-server.properties    configurazione runtime principale
├── src/main/webapp/              Swagger UI, web.xml e context.xml Tomcat
├── src/test/java/                test unitari, repository ed end-to-end
├── vendor/maven/                 artefatti Maven non pubblici versionati
├── data/texts/                   dati runtime locali, non da versionare
├── logs/                         log runtime, non da versionare
└── target/                       output Maven, non da versionare
```

## Funzionalità completate

- Nuovo endpoint `GET /lexica/lexicalConcept`: valida il target esclusivamente
  nel graph fisso dei concept e restituisce tutte le label tipizzate e
  multilingui, le definizioni, le entry collegate tramite `isEvokedBy`/`evokes`,
  i sense collegati tramite `lexicalizedSense`/`isLexicalizedSenseOf`, i concept
  set, figli e parent SKOS diretti/transitivi e i metadata nel formato comune.
  Entry e sense vengono arricchiti soltanto dai graph `lexica/{language}` ISO
  validi con i fallback richiesti; default graph, graph legacy e graph con
  pseudo-codici lingua restano esclusi.
- Nuovi endpoint `GET`, `PATCH` e `DELETE /metadata`: leggono, sostituiscono e
  cancellano metadati RDF multivalore su lexical entry, lexical sense, form,
  lexical concept e attestazioni. Entry, sense e form richiedono la lingua e
  usano il relativo graph linguistico; il resolver seleziona internamente anche
  il graph fisso dei concept o il graph documentale, verifica tipo e sottoclassi
  ammesse e applica la policy globale dei predicati protetti. Il PATCH mantiene
  `properties` per il replace completo e offre `addValues`/`removeValues` per
  variazioni esatte, idempotenti e atomiche che preservano gli altri valori.
- `MetadataPolicy` vieta per ogni entità presente e futura tutti i predicati nei
  namespace OntoLex, FRAC, LIME, VarTrans, SynSem, SKOS e Decomp, oltre a
  `dcterms:creator`, `dcterms:created`, `dcterms:modified`, `rdf:type` e
  `rdf:value`; `skos:note` è l'eccezione permanente, ammessa in scrittura e
  inclusa negli output metadata. La regola vale su creazione, CRUD e output,
  inclusi dati legacy.
- DTO e codec RDF comuni preservano IRI, literal semplici, language tag e
  datatype. Entry e attestazioni riusano il codec; la creazione del lexical
  concept accetta e restituisce ora `metadata` nella forma comune.
- Nuovo endpoint `POST /lexica/lexicalConcept`: crea atomicamente un
  `ontolex:LexicalConcept` con liste multilingui di label e definizioni, audit
  Dublin Core e collegamenti opzionali a sensi, parent e concept set. Tutti gli
  parent e concept set vengono verificati per esistenza e tipo nel graph fisso;
  ogni senso usa invece `{senseId, language}` ed è verificato nel relativo graph
  `lexica/{language}`. `metadata` può essere omesso o essere una lista vuota e
  la risposta `201` espone IRI, autore, timestamp e collegamenti. Il collegamento
  dal concept al sense resta nel graph fisso e usa
  `ontolex:lexicalizedSense`, non il predicato inverso
  `ontolex:isLexicalizedSenseOf`.
- Nuovo endpoint `PATCH /lexica/lexicalConcept`: sostituisce atomicamente i soli
  campi forniti tra label, definizioni e collegamenti semantici nel graph fisso
  di categoria. Campi assenti restano invariati, liste vuote rimuovono i valori
  opzionali e `null` esplicito rimuove parent o concept set; creator, data di
  creazione e metadata comuni restano invariati. Quando `senses` è presente,
  il servizio rimuove anche eventuali triple errate pregresse con
  `ontolex:isLexicalizedSenseOf` e scrive `ontolex:lexicalizedSense`; ciascun
  senso è prima validato nel graph della lingua dichiarata. Il precedente input
  ambiguo `senseId` viene rifiutato con `SENSE_LANGUAGE_REQUIRED`. Per evitare
  di reinviare l'intera collezione, `addSenses` aggiunge link validati per lingua
  e `removeSenseIds` rimuove soltanto gli IRI indicati; le operazioni sono
  idempotenti, atomiche e non possono essere combinate con il replace `senses`.
  Anche preferred label, alternative label, hidden label e definition espongono
  coppie add/remove distinte che preservano gli altri valori; le preferred label
  non possono essere rimosse tutte.
- Servizi CRUD e di consultazione per lessici OntoLex-Lemon, dizionari Lexicog,
  forme, sensi, concetti SKOS, relazioni, ECD, statistiche ed export RDF.
- Nuovo endpoint `POST /lexica/entry` nella risorsa incrementale `Lexicon`: crea
  atomicamente un'entrata, l'eventuale forma canonica e più sensi RDF, riusa o
  crea il `lime:Lexicon` della lingua e restituisce tutti gli IRI creati. Tipo
  dell'entrata e parte del discorso vengono validati nei graph linguistico e di
  schema. Entrata e sensi accettano metadata RDF multivalore con IRI e letterali
  e riusano la policy globale dei predicati protetti.
- Nuovo endpoint `PATCH /lexica/entry`: modifica atomicamente label, tipo RDF e
  parte del discorso nel solo graph ISO della lingua. I campi assenti restano
  invariati, `pos: null` rimuove la relazione e metadata, status, forme e sensi
  non vengono toccati.
- Nuovo endpoint `GET /lexica/{language}/entries`: restituisce tutte le entrate
  del lessico linguistico con filtri opzionali congiuntivi per label a fallback
  esclusivo, tipo RDF, parte del discorso, creator, stato e conteggio esatto dei
  sensi. La ricerca supporta inizio/contenimento/fine e confronto sensibile o
  insensibile al caso; le risorse di tipo e POS vengono validate nei graph
  linguistico e di schema. Ogni elemento espone inoltre IRI e cardinalità di
  sensi, forma canonica e altre forme, più i metadata RDF filtrati tramite la
  policy globale condivisa.
- Nuovo endpoint `PATCH /lexica/entries/status`: cambia atomicamente lo stato di
  una o più entrate dello stesso graph linguistico, controlla lo stato atteso e
  le sole transizioni `working`/`completed`/`revised` consentite, aggiorna
  `dcterms:modified` e registra l'account in `lexo:statusChangedBy`. Lo status
  iniziale `working` resta assegnato all'entrata creata, ma non al
  `lime:Lexicon` contenitore.
- Configurazione senza profili Maven: GraphDB locale, repository fissi
  `LexOLexica` e `LexOTexts`.
- Bootstrap idempotente all'avvio: creazione dei due repository GraphDB Free,
  import di schema/ontologie e creazione degli indici lessicali da risorse
  versionate nel classpath.
- Separazione parametrica dei repository in `GraphDbUtil`/`RDFQueryUtil`.
- Scritture lessicali nel graph `lexica`, senza uso del default graph.
- Graph separati per attestazioni e annotazioni di ciascun testo, con cleanup
  coordinato alla cancellazione del testo; il cleanup elimina inoltre in tutto
  `LexOLexica` ogni riferimento entrante e uscente alle attestazioni individuate
  nel graph del documento.
- Endpoint `administration/repositories` con statistiche per repository e per i
  graph lessicali, attestazioni, annotazioni e schema.
- Import testuale di TXT semplice, CommonMark controllato ed eventuale CoNLL-U.
- Front matter con valori singoli o multipli per `id`, `title`, `author`, `date`,
  `description`, `format` e `corpus`; valori URI gestiti secondo le
  regole documentate. `description` è sempre un letterale `dcterms:description`.
- Upload TXT/CommonMark con campo multipart obbligatorio `language`, validato
  contro le prime quattro colonne della lista ISO 639 inclusa nel progetto. Il
  codice normalizzato è persistito come `dcterms:language` e language tag NIF;
  la chiave `language` nel front matter viene ignorata.
- Conversione asincrona in NIF, polling, cancellazione, download di NIF,
  originale, testo canonico e CoNLL-U.
- Endpoint `POST /texts/bulk` per caricare e convertire più TXT/CommonMark/JSON
  con una sola lingua. I JSON hanno schema chiuso, testo TXT, corpus proprio e
  attestazioni FRAC; il polling espone stato e scarti delle attestazioni senza
  confonderli con la conversione. Il corpus query resta compatibile con i soli
  TXT/CommonMark. L'ammissione è atomica e vieta ogni CoNLL-U; dopo
  l'accettazione i job e i rollback dei documenti sono indipendenti.
- Creazione, consultazione, download ed eliminazione di corpora NIF senza testo;
  collegamenti bidirezionali `dcterms:hasPart`/`dcterms:isPartOf`.
- Endpoint `PUT /texts/{fileId}/total` e
  `PUT /texts/corpora/{corpusId}/total` per creare o sostituire atomicamente un
  `frac:total` nel graph documento/corpus. Sono ammesse le unità
  `lexo:tokens`, `lexo:types`, `lexo:lemmas` e `lexo:sentences`; la sostituzione
  riguarda soltanto la stessa unità e conserva gli altri totali.
- Catalogo testi filtrabile per corpus con nome, dimensione, conteggio di frasi,
  token, attestazioni, annotazioni e metadati disponibili.
- Rollback e pulizia degli artefatti in caso di errore; conservazione degli
  originali dopo conversione riuscita.
- Correzione delle ricerche esatte di lexical entry, forme, sensi e dictionary
  entry quando manca una label.
- Suite corrente: 172 test unitari/repository passati il 7 agosto 2026, inclusi
  i 3 test repository del dettaglio completo dei lexical concept, i 5 test di
  regressione della deserializzazione MOXy dei valori RDF, i 7 test repository
  dei servizi PATCH e i 9 test del contratto Swagger di `Lexicon`, oltre ai
  test del nuovo lexical concept manager e degli
  altri servizi lessicali, i 3
  test repository dei totali FRAC,
  i 6 test mirati del bulk testuale, i 42 test delle attestazioni, i 2 test del
  conteggio attestazioni nei lexical concept e i 4 test della creazione dei
  lexical concept con label.
- Endpoint `POST /attestations` per creare una o più attestazioni FRAC e i
  relativi loci NIF, con validazione di tipi OntoLex/DCMI, URL esterni, offset
  Unicode e isolamento nei named graph per testo.
- La validazione degli observable cerca entry, form e sense esclusivamente nei
  graph `lexica/{language}` e i lexical concept esclusivamente nel graph fisso
  `lexicalConcept`. Il graph legacy `lexica`, il default graph, i named graph
  estranei e le categorie collocate nel graph sbagliato sono esclusi.
- Endpoint `POST /attestations/by-locus` per creare atomicamente una attestazione
  per ogni IRI nella lista `observables`, condividendo lo stesso intervallo e lo
  stesso locus NIF nel corpus indicato. Ogni elemento è un oggetto con IRI
  `observable` e `metadata` opzionali nella struttura comune; le triple hanno
  come soggetto esclusivamente l'IRI della relativa attestazione.
- La creazione delle attestazioni riutilizza i loci NIF deterministici già
  presenti per parole, frasi o strutture quando `anchorOf`, `beginIndex`,
  `endIndex` e `referenceContext` coincidono, senza alterarne i tipi RDF; il
  codice `LOCUS_CONFLICT` resta riservato a differenze effettive nei dati
  identificativi del locus.
- La creazione accetta ora una lista JSON di occorrenze e valida l'intero batch
  prima di scrivere tutte le attestazioni e i loci in una transazione per
  repository, con compensazione tra `LexOLexica` e `LexOTexts`. Il metadato
  `dcterms:language` del contesto testuale viene applicato a `nif:anchorOf`,
  `frac:gloss` e `rdf:value` quando disponibile. Le occorrenze non accettano più
  `description` e le nuove attestazioni non scrivono `dcterms:description`.
- Endpoint paginato `POST /attestations/{fileId}` con filtri opzionali per IRI
  esatta dell'observable, tipo dell'osservabile e creator, arricchito con i dati
  del locus da `LexOTexts`; ogni filtro viene applicato prima di conteggio e
  paginazione.
- Endpoint paginato `POST /attestations/by-observable` per recuperare le
  attestazioni di un observable attraverso tutti i named graph per documento,
  con lo stesso output arricchito del servizio per testo.
- Entrambi gli endpoint di consultazione accettano un albero limitato di filtri
  `AND`/`OR` su creator dell'attestazione, metadati RDF esatti del testo e più
  tipi dell'observable in alternativa. Il filtro dei tipi segue anche
  `rdfs:subClassOf`; i parametri legacy `author` e `observableType` del servizio
  per testo restano compatibili e vengono combinati in `AND`. Entrambi usano 50
  risultati come dimensione predefinita della pagina.
- Endpoint `PATCH /attestations/{fileId}/locus` per spostare il locus di una
  singola attestazione a nuovi offset Unicode. Il valore viene ricalcolato dal
  `nif:isString`, l'IRI RFC5147 e le triple NIF vengono aggiornati in
  `LexOTexts`, mentre `rdf:value`, `dcterms:modified` e, per default,
  `frac:gloss` vengono aggiornati in `LexOLexica`. I loci condivisi o non
  marcati come generati da LexO sono rifiutati senza modifiche.
- Endpoint `PATCH /attestations/{fileId}/observable` per sostituire atomicamente
  il collegamento inverso `frac:attestation` di una o più attestazioni dopo la
  validazione completa del batch e del nuovo tipo OntoLex.
- I servizi di creazione mantengono un oggetto `frac:Frequency` per coppia
  observable/testo nel named graph documentale, con `rdf:value` `xsd:int` e
  `frac:observedIn` sul contesto NIF specifico. Cancellazioni per observable o
  locus e sostituzione dell'observable riallineano tutti i conteggi coinvolti e
  rimuovono la frequenza quando il valore residuo è zero. I JSON di creazione e
  consultazione espongono `frequency`; gli altri JSON di mutazione espongono la
  mappa `frequencies`.
- Endpoint `DELETE /attestations/{fileId}/by-observable` e
  `DELETE /attestations/{fileId}/by-locus` per cancellare atomicamente una lista
  esplicita di attestazioni oppure tutte quelle che corrispondono al criterio
  con `all: true`, sempre nel named graph selezionato da `fileId`.
- I loci creati dai servizi di attestazione sono marcati con
  `prov:wasGeneratedBy lexo:AttestationService`. La cancellazione elimina da
  `LexOTexts` soltanto i loci marcati rimasti senza attestazioni in tutta la
  famiglia dei graph di attestazione; i loci preesistenti o ancora referenziati
  vengono conservati.
- Le risposte di creazione e consultazione non espongono `description`.
- La consultazione paginata espone i metadata personalizzati in una mappa per
  IRI di proprietà, applicando la policy globale dei predicati protetti.
- Gli elementi restituiti da `GET /data/lexicalConcepts` e dalla ricerca
  filtrata espongono `attestations`, conteggio distinto dei collegamenti
  `frac:attestation` presenti nei named graph di attestazione per documento;
  il valore è `0` quando il concetto non ha attestazioni.
- `GET /create/lexicalConcept` accetta `label` e `language` facoltativi. Se la
  label è presente, la lingua è obbligatoria e deve appartenere alle prime
  quattro colonne della lista ISO 639 versionata; il codice normalizzato viene
  usato nel literal `skos:prefLabel` del graph `lexica`. La risposta espone la
  label nel nuovo campo JSON `label` e la lingua normalizzata in `language`.
- Ogni attestazione consultata espone `observableLabel`, risolto in base al tipo
  OntoLex usando label RDFS/SKOS, forma canonica e definizione del senso con i
  fallback documentati; sono riconosciute anche sottoclassi di `LexicalEntry` e
  i language tag sono preservati nel formato `valore@lingua`.
- Per un `ontolex:LexicalSense`, la label combina la label (o forma canonica)
  della entry collegata tramite `ontolex:sense` (l'inversa inferita è
  `ontolex:isSenseOf`) e `skos:definition`; se manca la
  definizione viene restituita la sola label della entry, mentre se manca la
  label viene restituita la sola definizione.
- Namespace applicativo predefinito aggiornato a `https://lexo.ilc.cnr.it#`.

## Funzionalità ancora da completare o validare

- Se necessario dopo misure su GraphDB reale, tradurre anche i filtri combinati
  per creator, tipo observable e metadata testuali nel piano SPARQL paginato.
  Attualmente questi casi preservano la selezione Java precedente, ma
  beneficiano già del caricamento batch dei dettagli della sola pagina.
- Implementare progressivamente i restanti CRUD per lexical concepts e concept
  sets nella classe `Lexicon.java`. Creazione, lettura completa e modifica del
  lexical concept sono completate; gli endpoint futuri continueranno a usare
  esclusivamente il graph fisso di categoria senza modificare i servizi legacy.
- Eseguire regolarmente `TextServicesIT` e `TextServiceUseCasesIT` contro una
  coppia di repository e una directory filesystem dedicati ai test. Questi test
  sono esclusi da `mvn test` e non sono stati eseguiti nell'ultima validazione;
  `TextServicesIT` include ora anche esito bulk parziale e rifiuto CoNLL-U.
- Decidere se completare o rimuovere i metodi legacy che lanciano ancora
  `UnsupportedOperationException` in alcuni manager (ad esempio creazione e
  cancellazione lessicale, SKOS, utenti, Zotero e amministrazione).
- Risolvere i TODO residui su aggiornamento dei timestamp, validazione dei tipi
  nelle relazioni lessicali, conversione TBX interattiva e ottimizzazione CoNLL.
- Configurare e collaudare Keycloak quando l'autenticazione reale è richiesta:
  le proprietà sono commentate nella configurazione predefinita.
- Ampliare i test automatici dei servizi lessicali: la copertura più completa al
  momento riguarda il dominio testuale e i named graph.
- Aggiungere test end-to-end REST per ricerca filtrata, aggiornamento locus e
  aggiornamento observable delle attestazioni; al momento la logica è coperta
  da test repository.
- Aggiungere test end-to-end REST per i totali FRAC di testi e corpora; la
  validazione e la persistenza sono attualmente coperte da test repository.

## Decisioni tecniche importanti

- Non reintrodurre MySQL, Hibernate, Spring o GraphDB embedded.
- Non reintrodurre profili Maven per scegliere repository/ambienti. La
  configurazione runtime risiede in `lexo-server.properties`.
- Tutto il dominio testuale deve usare `RepositoryTarget.TEXT`; dati lessicali,
  attestazioni e annotazioni usano `RepositoryTarget.LEXICON`.
- Le normali update lessicali operano nel graph `lexica`. Attestazioni e
  annotazioni richiedono sempre il `fileId` per selezionare il graph del testo.
- I nuovi CRUD lessicali selezionano il graph in base alla categoria dichiarata:
  le risorse dipendenti dalla lingua usano `lexica/{language}`, mentre lexical
  concepts e concept sets usano esclusivamente il graph fisso
  `https://lexo.ilc.cnr.it/graphs/lexical/lexicalConcept`.
- Non scrivere dati applicativi nel default graph.
- Gli offset delle attestazioni sono riferiti al valore canonico `nif:isString`,
  con conteggio per code point Unicode, non al sorgente CommonMark renderizzato.
- I file originali e CoNLL-U sono persistiti sul filesystem; il testo canonico
  non va duplicato in `canonical.txt` e i record non vanno duplicati in
  `metadata.json`.
- Il bulk testuale usa una lingua comune e accetta TXT/CommonMark/JSON senza
  associazioni implicite basate sui nomi dei file. Il `corpusId` query non si
  applica ai JSON, che usano soltanto `metadata.corpus`. Gli errori di schema e
  ammissione eliminano tutto lo staging; gli errori di conversione eliminano
  soltanto il documento interessato e le attestazioni non valide sono omesse e
  rendicontate singolarmente.
- I metadati multipli devono restare multipli nel modello RDF e nelle risposte.
- Le asserzioni RDF devono confrontare il modello semantico, non il testo Turtle.
- Il bootstrap è checksum-based e deve restare idempotente.
- Il progetto usa ancora API `javax.*` e target Java 8: evitare Jakarta/Tomcat 10
  o sintassi Java successiva senza una migrazione esplicita.

## Problemi noti

- I vecchi log già tracciati restano nella storia Git; `.gitignore` esclude ora
  log, dati runtime, backup locali e artefatti IDE dalle nuove modifiche.
- Alcune classi legacy contengono stub `UnsupportedOperationException` e TODO.
- L'autenticazione Keycloak è disattivata nella configurazione predefinita.
- Il bootstrap è configurato con `Bootstrap.required=true`: se GraphDB non è
  raggiungibile o il bootstrap fallisce, l'applicazione non deve considerarsi
  correttamente avviata.
- I default tradizionali puntano a `localhost:7200`; Compose applica invece gli
  URL interni del servizio GraphDB tramite variabili d'ambiente. Un deployment
  esterno deve fornire esplicitamente gli URL effettivi.
- Docker Desktop/Engine 20.10.7 costruisce ed esegue correttamente lo stack, ma
  è una versione del 2021 non più adeguata come riferimento di sicurezza. Per
  uso ordinario è raccomandato l'aggiornamento a una release supportata; gli
  script backup/restore/update richiedono ancora un collaudo end-to-end.
- I record aggregati dei bulk sono mantenuti in memoria: i documenti e i job già
  avviati restano gestiti individualmente, ma dopo un riavvio non è più
  disponibile il polling tramite il precedente `bulkId`.
- Anche i job di cancellazione multipla sono mantenuti soltanto in memoria e
  vengono eseguiti da un singolo worker; più job vengono quindi accodati e il
  polling di un `bulkId` precedente non è disponibile dopo un riavvio.
- `POST /attestations` richiede una lista JSON al livello principale. Con un
  oggetto JSON, Jersey/MOXy fallisce prima dell'ingresso nel metodo con
  `IllegalArgumentException: argument type mismatch` e restituisce HTTP 500
  invece di un errore applicativo 400; il client deve inviare l'array documentato.
- In ambienti Codex senza `mvn` nel `PATH` è stato usato Maven incluso in
  NetBeans 12.2. Il sandbox può mostrare warning se non può scrivere in `~/.m2`.

## Installazione, build, avvio e test

Il percorso consigliato per un'installazione locale completa è Docker:

```bash
cp .env.example .env
docker compose up -d --build
docker compose ps
```

Per installare un WAR nuovo senza sostituire i volumi persistenti:

```bash
./docker/build-war-image.sh /percorso/LexO-server.war VERSIONE
./docker/update.sh VERSIONE
```

La procedura dettagliata, inclusi backup e restore, è in `docs/docker.md`.

Prerequisiti: JDK compatibile, Maven 3.8+, GraphDB Free e Tomcat 9.

```bash
# Build del WAR
mvn clean package

# Test unitari/repository (gli *IT.java sono esclusi)
mvn test

# Deploy manuale di esempio
cp target/LexO-server.war "$CATALINA_BASE/webapps/"
"$CATALINA_HOME/bin/startup.sh"
```

Con GraphDB attivo su `http://localhost:7200`, il bootstrap crea automaticamente
i repository mancanti. Swagger è disponibile su:

```text
http://localhost:8080/LexO-server/
```

Esempio minimo per gli end-to-end:

```bash
mvn verify \
  -Dlexo.test.baseUrl=http://localhost:8080/LexO-server/service \
  -Dlexo.test.authorization='Bearer TOKEN_LEXO' \
  -Dlexo.test.graphdbUrl=http://localhost:7200 \
  -Dlexo.test.textRepository=LexOTexts \
  -Dlexo.test.storageDir=/percorso/assoluto/data/texts
```

Usare esclusivamente repository e directory dedicati ai test. Per tutti i
dettagli consultare `docs/text-services-tests.md`.

Se `mvn` non è nel `PATH` nell'ambiente Codex locale:

```bash
/Applications/NetBeans/Apache\ NetBeans\ 12.2.app/Contents/Resources/NetBeans/netbeans/java/maven/bin/mvn test
```

## Stato Git

- Branch di consegna corrente: `cpp`, richiesto dall'utente.
- Base verificata con fetch di `origin/master` e fast-forward: `d4429e3`.
- Primo commit CPP: `b03e398`, bootstrap e ontologie.
- Il commit `Record and export CPP collocation extraction provenance` completa
  API, mapper, repository, limiti, test e documentazione.
- Pubblicazione sul branch remoto corrispondente `origin/cpp`, senza PR e senza
  modificare `master` o riscrivere storia.
- Nessuna modifica utente preesistente all'avvio; artefatti runtime, IDE e WAR
  restano esclusi dai commit.

## Ultimi file modificati

Per CPP: `service/CppRuns.java`, `manager/CppRunManager.java`, componenti sotto
`manager/cpp`, DTO sotto `service/data/cpp`, normalizzazione condivisa
`CollocateExtractionParameters`, manifest e risorse bootstrap, proprietà,
`CppRunManagerTest`, `CppContractTest`, `CppRunsTest`, `CppRunsIT` e
`GraphDbBootstrapTest`. Contratto e deployment in `docs/cpp-run-services.md`;
aggiornati test-services, CHANGELOG Unreleased e questo handoff.

Cronologia precedente: per l'export dell'8 settembre: `Attestations.java`, `AttestationManager.java`,
`AttestationWebAnnotationExporter.java`, `WebAnnotationExportException.java`,
`LexicalNamedGraphs.java`, i DTO `WebAnnotationDocument`/`AttestationProvenance`,
la proprietà `webAnnotation.quoteContextLength`, i test
`AttestationWebAnnotationExporterTest`/`AttestationsExportTest`/`AttestationsExportIT`,
il contesto locale e lo script di verifica JSON-LD 1.1. Contratto completo in
`docs/attestation-web-annotation-export.md`; aggiornati README, documentazione
test, CHANGELOG Unreleased e questo handoff.

Cronologia delle attività precedenti:

Il lavoro corrente aggiunge `TextBulkDeletionManager`, i DTO di input e stato,
gli endpoint `DELETE /texts/bulk` e
`GET /texts/deletions/{bulkId}/status`, i test unitari del manager e del routing
e uno scenario opzionale in `TextServicesIT`. README, documentazione dei test e
changelog descrivono il contratto asincrono e gli esiti indipendenti. La
cancellazione di ciascun elemento delega a `TextJobManager.delete`, quindi
mantiene tutte le politiche già verificate per record NIF, corpus, graph di
attestazioni e annotazioni, riferimenti cross-graph, frequency e filesystem.
La suite completa del 25 agosto 2026 ha eseguito 197 test senza errori o test
saltati; l'end-to-end aggiunto resta da eseguire in un deployment isolato.

Il lavoro corrente modifica `LexicalTextGraphManager` per raccogliere le
attestazioni dal graph selezionato prima del cleanup e rimuovere tutte le loro
triple entranti e uscenti in una sola transazione `LexOLexica`. Il follow-up
centralizza creazione e sincronizzazione delle frequency in
`AttestationFrequencySupport` e ricalcola quelle degli observable coinvolti in
altri graph documentali. `LexicalTextGraphManagerTest` copre riferimenti
incrociati tra graph, attestazioni riconosciute dal tipo o dal link FRAC,
decremento della frequency, rimozione a zero e isolamento degli altri testi.
Sono stati aggiornati Swagger, README, bootstrap, documentazione dei test e
changelog. I 49 test mirati sono passati il 21 agosto 2026; la suite completa ha
eseguito 178 test senza errori o test saltati e gli end-to-end REST restano
esclusi.

Il lavoro corrente aggiunge `GET /lexica/lexicalConcept` in `Lexicon.java`,
`LexicalConceptDetailsManager` e i DTO di risposta sotto
`service/data/lexicon/output`. Il servizio valida il target nel graph fisso,
risolve entry e sense esclusivamente nei graph ISO, applica i fallback di label
richiesti, separa le relazioni SKOS dirette e transitive e serializza i metadata
tramite `MetadataPolicy` e `RdfMetadataCodec`. I 3 test repository dedicati, i
9 test Swagger di `Lexicon` e la suite completa di 172 test sono passati il 7
agosto 2026; gli end-to-end REST contro GraphDB/Tomcat non sono stati eseguiti.

Il lavoro precedente aggiunge `PATCH /lexica/entry` e
`PATCH /lexica/lexicalConcept` in `Lexicon.java`, i DTO presence-aware sotto
`service/data/lexicon`, i risultati senza metadata e i manager transazionali
`LexicalEntryUpdateManager` e `LexicalConceptUpdateManager`. L'entry update usa
esclusivamente `lexica/{language}`, mentre il concept update usa esclusivamente
il graph fisso `lexicalConcept`; entrambi supportano il controllo concorrente
opzionale `expectedModified`, preservano creator e data di creazione e
aggiornano `dcterms:modified`. I metadata non fanno parte dei due contratti e
restano modificabili soltanto tramite `/metadata`. I test mirati dei servizi
PATCH, i 5 test MOXy, il test esplicito dell'eccezione `skos:note` e la suite
completa di 168 test unitari/repository sono passati il 6 agosto 2026. La
creazione dei concept e il relativo PATCH usano oggetti
`{senseId, language}` per sostituzioni e aggiunte: verificano la risorsa nel
graph lessicale della lingua e scrivono `ontolex:lexicalizedSense` nel graph
fisso dei concept. Il PATCH supporta inoltre `removeSenseIds` senza richiedere
di rileggere o reinviare gli altri collegamenti, ed elimina eventuali asserzioni
pregresse errate con l'inverso per ogni modifica dei sensi. Il lavoro corrente
aggiunge inoltre add/remove distinti per preferred, alternative e hidden label,
definition e valori metadata RDF esatti. I test mirati coprono replace,
add, remove, idempotenza, conflitti, cardinalità delle preferred label,
rollback, graph, lingua e tipo RDF. Gli 11 test mirati dei manager metadata e
lexical concept sono passati il 6 agosto 2026.
Gli
end-to-end REST contro GraphDB/Tomcat non sono stati eseguiti.

La risposta di `GET /lexica/{language}/entries` include ora `senses`,
`canonicalFormNumber`, `canonicalForm`, `otherFormNumber`, `otherForms` e
`metadata`, oltre al precedente `senseNumber`. Liste e conteggi sono coerenti e
ordinati deterministicamente; i metadata riusano `RdfMetadataCodec` e
`MetadataPolicy`, quindi preservano il tipo RDF dei valori e omettono ogni
predicato protetto anche sui dati legacy.

Il lavoro corrente rende monotona la componente millisecondo delle IRI delle
attestazioni: se il clock non avanza o il candidato è già presente nel
repository, il manager seleziona il millisecondo successivo libero mantenendo
coerenti IRI e timestamp audit. Un test con clock bloccato riproduce e copre la
precedente collisione. Lo stesso lavoro trasforma ogni elemento di `observables`
della create
by-locus in un oggetto con `observable` obbligatorio e `metadata` opzionali nella
struttura comune `{property, values}`. `AttestationManager` usa
`RdfMetadataCodec` e `MetadataPolicy`, aggiunge ogni valore al modello con
soggetto l'IRI della specifica attestazione e persiste l'intero batch nel named
graph documentale. La risposta conserva la struttura delle attestazioni e
include i metadata creati. I 40 test mirati e la suite completa di 147 test sono
passati il 4 agosto 2026; gli end-to-end REST non sono stati eseguiti.

È stata predisposta e usata la base della riscrittura incrementale dei CRUD
lessicali, senza rimuovere o modificare gli endpoint legacy. La nuova risorsa
`service/Lexicon.java` risponde alla radice `lexica`, espone il tag Swagger
`Lexica` e contiene anche `POST /lexica/lexicalConcept`, oltre a
`POST /lexica/entry`, `GET /lexica/{language}/entries` e
`PATCH /lexica/entries/status`. `LexicalConceptManager` valida prima della
scrittura label ISO 639 e collegamenti tipizzati, quindi persiste tutte le
triple in una transazione del graph fisso di categoria.
`LexicalEntryStatusManager` valida l'intero
batch prima di scrivere, limita i target alle entrate OntoLex del graph
linguistico, applica il rollback su ogni errore e mantiene autore e timestamp
della transizione. I relativi DTO sono sotto `service/data/lexicon` e
`LexicalWorkflowStatus` centralizza valori e transizioni ammesse.
La risorsa `service/Metadata.java`, `manager/metadata/MetadataManager` e
`RdfMetadataCodec` e `MetadataPolicy` costituiscono il nuovo nucleo condiviso. I DTO sotto
`service/data/metadata` definiscono una sola rappresentazione JSON per input e
output; nuove categorie registrano soltanto tipo e graph e riusano senza
deroghe la policy globale dei predicati protetti. `lexicalSense` e `form` sono
ora categorie ammesse insieme a `lexicalEntry`: richiedono `language`, usano il
named graph linguistico e accettano il tipo OntoLex previsto o una sottoclasse
transitiva dichiarata nel graph o nello schema.
`LexiconCrudSupport` centralizza anche il graph fisso dei lexical concept e il
prefisso SKOS, oltre alla selezione del named graph specifico per
lingua sotto `https://lexo.ilc.cnr.it/graphs/lexical/lexica/{language}`, la
generazione delle IRI tramite namespace, instance id e timestamp configurati
con la normalizzazione `_`, e il fallback `anonymous` per autori nulli o vuoti.
I codici lingua vengono validati contro le prime quattro colonne della lista
ISO 639 versionata nelle risorse e normalizzati in minuscolo tramite
`Iso639LanguageValidator`, così valori sintatticamente plausibili ma non
presenti nel file vengono rifiutati e lingue diverse restano in graph distinti.
Il contratto completo è in `docs/lexicon-services.md` ed è richiamato dalle
regole permanenti in `AGENTS.md`. `LexicalEntryManager` usa
`GraphDbUtil.getConnection(RepositoryTarget.LEXICON)`, completa le validazioni
prima delle scritture e persiste l'intero modello in una singola transazione del
graph linguistico. Lo stesso contratto fissa i namespace `decomp`, `vartrans`,
`ontolex`, `synsem`, `lexinfo` 3.0, `lime`, `lexicog` e `skos`.
Le collezioni `properties` e `metadata` di ogni senso condividono ora la stessa
struttura JSON: una lista di oggetti con `property` e `values`, dove `values` è
multivalore. La policy globale dei predicati protetti si applica a `metadata`.
I 6 test mirati di `MetadataManagerTest` e `MetadataTest` e la suite completa di
147 test unitari/repository sono passati il 4 agosto 2026. Gli end-to-end `*IT`
non sono stati eseguiti; Maven ha
riportato i warning ambientali già noti su SLF4J, codice legacy
deprecato/unchecked e impossibilità del sandbox di aggiornare tracking file in
`~/.m2`.

Il lavoro corrente aggiunge due endpoint `PUT` in `Texts`, i DTO
`TextTotalInput`/`TextTotalResult`, il manager condiviso `TextTotalManager` e la
scrittura transazionale in `TextNifRepository`. Il soggetto del testo è il suo
contesto NIF, mentre il soggetto del corpus è la relativa IRI. Una scrittura
rimuove tutti i nodi `frac:total` della stessa unità e ne crea uno canonico con
tipo `frac:Frequency`, valore `xsd:int` e unità IRI; le altre unità restano
invariate. `TextNifRepository` usa ora inizializzazione lazy per permettere test
in-memory senza connessioni GraphDB implicite. I 3 test dedicati e la suite
completa di 99 test sono passati il 30 luglio 2026; gli end-to-end REST restano
da eseguire in un ambiente dedicato.

Il lavoro precedente aggiunge `PATCH /attestations/{fileId}/locus` e
`PATCH /attestations/{fileId}/observable`. Il primo ricava la nuova anchor dal
testo canonico con offset Unicode e ricollega una singola attestazione all'IRI
`#char=start,end`: crea la destinazione se assente, riusa una destinazione
compatibile se già presente e conserva il vecchio locus quando è di sistema o
ancora condiviso. Un vecchio locus LexO viene eliminato soltanto se orfano. Le
transazioni sui due repository mantengono la compensazione. Il secondo
sostituisce atomicamente l'observable per una lista validata di attestazioni
nello stesso named graph. I DTO dedicati documentano input e risultati, inclusi
`updateGloss`, locus precedente e observable precedenti.

Lo stesso lavoro precedente aggiunge inoltre
`POST /attestations/by-observable` e il DTO ricorsivo
`AttestationFilter`, condiviso con `POST /attestations/{fileId}`. I filtri
combinano creator, metadata RDF del contesto testuale e tipi OntoLex, preservano
la semantica esatta di IRI/literal, lingua e datatype, e riconoscono le
sottoclassi dichiarate nei graph lessicale e schema. La ricerca per observable
accetta soltanto membri validi della famiglia dei graph di attestazione e
arricchisce dopo la paginazione i risultati tramite `LexOTexts`.

Il branch di base aggiunge inoltre i due endpoint `DELETE` delle attestazioni e
una sola implementazione manager condivisa per validazione, selezione esplicita
o completa, cancellazione RDF e compensazione fra repository. I nuovi loci
ricevono il marcatore
`prov:wasGeneratedBy lexo:AttestationService`; un locus viene eliminato soltanto
quando è marcato e non è più referenziato da attestazioni. I test del 30 luglio
2026 ne verificano anche la cancellazione e la conservazione dei loci condivisi.

La creazione dei lexical concept accetta ora i parametri facoltativi `label` e
`language`; quando la label è presente la lingua è obbligatoria, validata sulla
lista ISO 639 inclusa e normalizzata. La scrittura usa sempre un literal
`skos:prefLabel` language-tagged nel graph `lexica`, anche quando la
configurazione lessicale generale usa un altro modello. Il DTO di creazione
espone il nuovo campo `label`. I quattro test dedicati verificano validazione,
escaping del literal, named graph, assenza nel default graph e JSON di output.

Il servizio `GET /data/lexicalConcepts` e la ricerca filtrata dei lexical concept
usano ora il campo JSON `attestations`. Le query contano i soli oggetti distinti
di `frac:attestation` nei graph sotto la base configurata delle attestazioni,
senza includere default graph o graph estranei; il test repository dedicato
verifica anche che il conteggio non alteri il numero di figli.

Nello stesso branch l'upload testuale è stato esteso con la lingua ISO 639
obbligatoria. I file principali coinvolti sono `Texts.java`, `TextJobManager.java`,
`Iso639LanguageValidator.java`, `ControlledCommonMarkParser.java`, la lista CSV
in `src/main/resources/iso639`, i test testuali e la relativa documentazione.
La suite completa conta ora 91 test; gli end-to-end `*IT` restano esclusi da
`mvn test` e richiedono un deployment dedicato.

L'ultimo commit (`9f77676`, supporto a `description`) ha modificato:

- `docs/text-services-tests.md`
- `src/main/java/it/cnr/ilc/lexo/manager/RepositoryStatisticsManager.java`
- `src/main/java/it/cnr/ilc/lexo/manager/text/ControlledCommonMarkParser.java`
- `src/main/java/it/cnr/ilc/lexo/manager/text/NifModelWriter.java`
- `src/main/java/it/cnr/ilc/lexo/manager/text/TextCatalogManager.java`
- `src/main/java/it/cnr/ilc/lexo/manager/text/TextNifRepository.java`
- `src/test/java/it/cnr/ilc/lexo/manager/text/ControlledCommonMarkParserTest.java`
- `src/test/java/it/cnr/ilc/lexo/manager/text/NifModelWriterTest.java`
- `src/test/java/it/cnr/ilc/lexo/manager/text/TextCatalogManagerTest.java`
- `src/test/java/it/cnr/ilc/lexo/manager/text/TextNifRepositoryTest.java`

Il commit precedente più ampio (`889be33`) ha introdotto la selezione parametrica
dei repository, il catalogo testi e i graph per-test di attestazioni/annotazioni;
queste aree sono quindi quelle con maggiore probabilità di regressioni incrociate.

Il file `CHANGELOG.md` è stato aggiunto come registro delle modifiche verificabili;
al momento non esistono tag Git, quindi tutte le voci restano nella sezione
`Unreleased`.

## Prossimo lavoro consigliato

1. Su un Docker Engine/Compose aggiornato e con volumi isolati, verificare
   persistenza, backup/restore e aggiornamento fra due tag WAR.
2. Aggiungere end-to-end REST dedicati a `POST` e `PATCH`
   `/lexica/lexicalConcept`, `POST` e `PATCH /lexica/entry` e
   `PATCH /lexica/entries/status` contro un repository `LexOLexica` isolato,
   inclusi validazione dei link, sostituzioni presence-aware, controllo
   `expectedModified`, riuso del lessico, transizioni batch e rollback.
3. Aggiungere test end-to-end dei nuovi endpoint di totali FRAC, creazione,
   cancellazione delle attestazioni e della
   creazione dei lexical concept con label contro repository GraphDB dedicati.
4. Gestire esplicitamente i body non-array di `POST /attestations` con una
   risposta HTTP 400 leggibile, evitando l'errore riflessivo Jersey/MOXy.
5. Preparare un ambiente E2E isolato e lanciare entrambi i workflow testuali
   completi, verificando REST, GraphDB e filesystem, inclusi i nuovi casi JSON
   con attestazioni, corpus per documento, lingua upload mancante/non valida e
   il relativo `dcterms:language` nel NIF.
6. Eseguire anche lo scenario end-to-end della cancellazione multipla e
   verificare gli esiti indipendenti contro GraphDB e filesystem dedicati.
7. Inventariare gli `UnsupportedOperationException` raggiungibili dagli endpoint
   e trasformare l'inventario in test o attività di rimozione/implementazione.
