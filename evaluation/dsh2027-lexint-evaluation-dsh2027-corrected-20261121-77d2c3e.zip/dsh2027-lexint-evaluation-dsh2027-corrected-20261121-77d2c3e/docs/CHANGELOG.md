# Changelog

All notable changes to this project will be documented in this file.

The repository currently has no Git tags or published releases, so the changelog
starts from the ongoing `Unreleased` work.

## [Unreleased]

### Added

- A reproducible DSH 2027 LexInt evaluation package now provides frozen RDF
  fixtures and oracles, T01–T12 REST/GraphDB tests, CQ01–CQ07 SPARQL answer
  checks, CE1–CE3 structural-SHACL comparisons, per-case evidence, machine and
  reviewer reports, and a deterministic replication archive from an isolated
  Docker stack.
- LexInt publication tests now include a test-only pre-commit fault injector
  that proves rollback after provisional active, snapshot and audit writes,
  without adding a public corruption endpoint.
- The corrected DSH 2027 package now proves T09 rollback against the dedicated
  GraphDB backend with independent pre/post connections and compares CQ01–CQ07
  as complete typed RDF-binding multisets, including adversarial association
  and duplicate-row tests.
- LexInt Management and Publication & Audit now run inside the existing WAR
  and `LexOLexica`, with claim/target/decision CRUD, server-managed versions,
  read-only preview, transactional per-target publication, persistent
  idempotency, immutable snapshots and repeatable historical audit APIs.
- Bootstrap now installs both LexInt ontologies in the lexical schema graph
  and both SHACL resources in an isolated shapes graph with independent
  checksums, idempotency and rollback. Runtime individuals receive centralized
  creator/created/modified metadata and authenticated publication requires the
  configured publisher role; all LexInt routes also have configurable bounded
  per-identity request limiting.

- A complete `/service/wordnet` REST API now manages WordNet roots, entries,
  forms, senses, synsets and explicit VarTrans relations, with selectable GET
  projections, paginated filters, stable Base64URL resource IDs, common RDF
  metadata, native WordNet annotations and a dedicated atomic Entry workflow.
- WordNet data now has an isolated third GraphDB repository, `LexOWordnets`,
  with one named graph per WordNet and independent schema/bootstrap graphs.
  Startup creates it idempotently and imports the pinned GWA 1.4 ontology plus
  local dependencies from verified, runtime-local resources.

- Co-occurrence search and collocate extraction now select node and collocate
  attributes independently as surface `TOKEN`, `LEMMA`, or `POS`, while
  preserving `TOKEN` defaults. Positional results expose available lemma/POS,
  and extracted groups report their observed surface, lemma, and POS variants.

- Full-text search now supports positional `LEMMA` fields sourced from persisted
  CoNLL-U/annotated token lemmas while preserving surface-token offsets and
  KWIC. Text catalogs, records, and folder members expose lemma counts and
  coverage; mixed subsets are rejected by default or explicitly reported when
  partial coverage is allowed. A side-effect-free validation endpoint uses the
  same Lucene parser and limits. The current index schema version 3 makes lemma
  fields and analyzer-driven case normalization rebuild requirements explicit.

- Hierarchical text folders now provide an independent RDF organization layer
  in `LexOTexts`, with arbitrary-depth trees, atomic folder and text moves,
  virtual unfiled listing, non-recursive safe deletion, stable REST errors, and
  Swagger documentation under `Text Organization`. The ontology is imported
  idempotently into a separate schema graph, while text deletion removes and,
  on rollback, restores folder membership without changing NIF, corpus, or
  Lucene data.
- Six CPP run endpoints now register declared collocation extraction provenance,
  list and read effective parameters, correct associations, delete provenance
  while preserving FrAC data, and export selected or all runs as flattened
  Turtle with optional existing scores. Writes are atomic in a dedicated graph,
  with caller-scoped idempotency and exclusive run ownership of collocations;
  provenance preserves validated `TOKEN`, `LEMMA`, or `POS` node and collocate
  selectors used by the integrated extraction API.

- CPP 0.2.1 and CollScore 1.2.0 schemas (18 measures) are now included in
  GraphDB bootstrap alongside the existing RDF/XML vocabularies.

- Standalone Apache Lucene corpus indexing now provides occurrence-level
  full-text search, phrase and multi-term queries, positional KWIC resizing,
  frequencies, co-occurrences and collocate extraction without GraphDB-specific
  full-text functions. Dedicated status, consistency verification, per-document
  reindex and safe rebuild endpoints support operation and migration.
- Canonical text and segmentation are now explicit shared inputs for NIF and
  Lucene, with CoNLL-U-first precedence, validated annotated-JSON spans,
  Unicode code-point offsets, provenance profiles and SHA-256 content and
  segmentation fingerprints. Collocation statistics and explicit FrAC
  persistence are exposed separately.
- Concise endpoint documentation now covers every implemented ECD creation,
  retrieval, update, and deletion service and identifies the declared routes
  that are still placeholders.

- `GET /attestations/export/web-annotation` exports selected or all attestation
  document graphs as Web Annotation JSON-LD, with Unicode text selectors and
  optional lossless LexO metadata/provenance. Missing canonical evidence or
  inconsistent records fail the entire request with a diagnostic HTTP 422.

- A Docker Compose starter distribution now runs versioned LexO-server/Tomcat
  and GraphDB containers with persistent data and log volumes, dependency-aware
  health checks, idempotent startup, coordinated backup/restore scripts, and a
  safe image-building and update workflow for newly supplied WAR files.
- `DELETE /texts/bulk` and `GET /texts/deletions/{bulkId}/status` now provide
  asynchronous multi-text deletion with ordered, independent per-text outcomes;
  every item applies the complete single-text cleanup policy, including corpus,
  attestation, annotation, frequency, and filesystem updates.
- `POST /texts/bulk` now accepts fixed-schema JSON documents containing plain
  text, the existing text metadata fields, an optional per-document corpus, and
  FRAC attestations whose observables are validated in their category named
  graphs. Status polling reports saved and unsaved attestations independently
  from text conversion.
- `GET /lexica/lexicalConcept` now returns one validated lexical concept with
  every multilingual label and definition, linked entries and senses resolved
  across ISO-language lexical graphs with ordered label fallbacks, concept-set
  memberships, direct and transitive SKOS hierarchy relations, and common RDF
  metadata.
- `PATCH /lexica/entry` now atomically updates a lexical entry's label, RDF
  type, or part of speech in its ISO-language named graph, with optional
  modification-time concurrency checking and without changing metadata,
  status, forms, or senses.
- `PATCH /lexica/lexicalConcept` now atomically replaces supplied multilingual
  labels, definitions, sense links, parent, or concept-set membership in the
  fixed lexical-concept graph, and supports idempotent incremental changes for
  preferred, alternative, and hidden labels, definitions, and sense links,
  while leaving common entity metadata untouched.
- `GET`, `PATCH`, and `DELETE /metadata` now provide common RDF metadata CRUD
  for lexical entries, lexical senses, forms, lexical concepts, and attestations
  with safe named-graph resolution, one global protected-predicate policy, and
  idempotent `addValues`/`removeValues` operations for exact RDF values.
- `POST /lexica/lexicalConcept` now accepts and returns multivalued RDF metadata
  using the common IRI/literal, language, and datatype representation.
- `POST /lexica/lexicalConcept` now atomically creates a multilingual lexical
  concept with audit metadata and optional validated links to lexical senses,
  a parent concept, and a concept set in the fixed LexOLexica lexical-concept
  named graph.
- `GET /lexica/{language}/entries` now returns the language lexicon's entries
  with conjunctive filters for fallback label text, type, part of speech,
  creator, workflow status, and exact sense count, including sense and form
  IRIs, relation cardinalities, and globally policy-filtered RDF metadata.
- `POST /lexica/entry` now atomically creates a lexical entry, an optional
  canonical form, and RDF-valued senses in the ISO-language-specific
  `LexOLexica` named graph, reusing or creating its `lime:Lexicon` and returning
  every created resource IRI.
- `PATCH /lexica/entries/status` now atomically changes the workflow status of
  one or more lexical entries in a language-specific named graph, validates
  the expected current status and legal transitions, and records the resolved
  author and modification timestamp.
- The non-public `OntoApi:1.0` Maven artifact is now bundled in the repository,
  allowing clean checkouts to resolve the dependency without a manual local
  Maven installation.
- A `POST /attestations` service now creates FRAC attestations and validated NIF
  loci for local or external textual evidence.
- A `POST /attestations/by-locus` batch service now creates one FRAC attestation
  per observable while sharing one validated NIF locus and transaction.
- A paginated `POST /attestations/{fileId}` service now retrieves one text's
  attestations with optional observable-type and creator filters and includes
  the corresponding NIF locus data.
- A paginated `POST /attestations/by-observable` service now retrieves one
  observable's attestations across all configured per-text attestation graphs.
- A `PATCH /attestations/{fileId}/locus` service now relinks one attestation to
  new Unicode code-point offsets and recalculates the attested value from the
  canonical text, reusing compatible system or LexO destinations, preserving
  system and shared previous loci, deleting only orphan LexO loci, and allowing
  optional gloss preservation.
- A `PATCH /attestations/{fileId}/observable` service now atomically replaces
  the observable of one or more attestations in one per-document graph.
- `DELETE /attestations/{fileId}/by-observable` and
  `DELETE /attestations/{fileId}/by-locus` services now atomically remove an
  explicit attestation list or all matching attestations in one text graph.
- Plain-text TXT import and NIF conversion for documents without CommonMark
  headings.
- Front matter support for `id`, `title`, `author`, `date`, `description`,
  `format`, and `corpus`, including multi-valued metadata and URI
  handling.
- Corpus creation, corpus membership, and corpus-aware text conversion.
- Dedicated GraphDB Free bootstrap for `LexOLexica` and `LexOTexts`, including
  schema import and lexical index creation at startup.
- Text services test coverage, including workflow-oriented integration tests.
- Repository administration statistics for lexical and text repositories.
- Text catalog/listing endpoints for browsing stored texts and their metadata.
- Bulk TXT/CommonMark upload and asynchronous conversion with one shared
  language, aggregate status polling, per-document rollback, and partial
  completion results. Bulk requests containing CoNLL-U are rejected before
  any conversion starts.
- `PUT /texts/{fileId}/total` and `PUT /texts/corpora/{corpusId}/total` now
  create or replace FRAC totals for texts and corpora using the supported token,
  type, lemma, and sentence units in their respective LexOTexts named graphs.

### Changed

- Historical LexInt versions now record snapshot cardinality in the private
  management ledger, so removal of a previously non-empty audit input appends
  an `INDETERMINATE` report instead of misclassifying missing evidence as an
  ordinary publication mismatch.
- The LexInt profile property is consistently named
  `lexint:targetAssertion` in the packaged ontology, shape and runtime code;
  the distinct Publication property remains `pub:targetAssertion`.
- When explicitly enabled for a language with a baseline, LexInt managed mode
  now prevents direct entry, status and metadata writers from bypassing the
  controlled publication workflow; defaults remain disabled for compatibility.

- The global metadata policy now protects the complete GWA WordNet namespace
  and the service-managed LexO workflow predicates, while retaining the
  permanent `skos:note` exception.

- Swagger now groups the ten corpus search, collocation, and Lucene index
  endpoints under `Text Search`, separately from the existing
  `Text Corpus NIF` services, without changing their REST paths.

- Apart from optional TXT front matter, plain TXT imports and JSON
  `text.content` now use strict UTF-8, remove one leading BOM, normalize CRLF/CR
  to LF and normalize Unicode to NFC while preserving all other whitespace.
  CommonMark rendering remains controlled, and offsets address the canonical
  `nif:isString` in Unicode code points. Text creation and deletion keep RDF/NIF
  and the standalone Lucene document consistent with compensation on failure.
- Runtime configuration can now be supplied through an external properties
  file, `LEXO_*` environment variables, or JVM system properties without
  rebuilding the WAR; filesystem paths and bounded GraphDB startup retries use
  the same configuration mechanism.
- Logging now uses a single SLF4J 2 and Log4j 2 backend with structured JSON,
  request correlation, HTTP status and duration, bounded rotation and
  retention, and context propagation into Metadata, Testo/NIF, Attestations,
  Lexica, and Conversion background work. Legacy services temporarily route
  through the Log4j 1 API adapter until they are replaced.
- Bulk text import now accepts mixed TXT/CommonMark/JSON requests under one
  required language. The query `corpusId` applies only to TXT/CommonMark and is
  rejected for JSON-only requests; duplicate JSON attestations remain distinct.
- `POST /attestations/{fileId}` now accepts an optional exact `observable` IRI
  filter, combined with the existing query and JSON filters before counting and
  pagination.
- Unfiltered `POST /attestations/{fileId}` retrieval, including exact-observable
  requests, now counts, orders, and paginates in GraphDB and batch-loads the
  selected FRAC and NIF details, avoiding full in-memory scans and per-field
  repository round trips.
- The global metadata policy now always permits `skos:note` on writes and
  includes it in metadata reads, while other SKOS properties remain protected.
- New lexical CRUD and attestation services now resolve application data only
  from category-specific named graphs: language graphs for entries, forms, and
  senses, the fixed concept graph for lexical concepts, and per-document graphs
  for attestations. The legacy lexical graph and default graph are no longer
  accepted by these services.
- `POST /lexica/entry` writes `ontolex:sense` in the language-specific named
  graph and leaves its inverse `ontolex:isSenseOf` to repository inference.
- Attestation responses for lexical senses now return the linked entry label
  alone when `skos:definition` is missing, while still combining entry label and
  definition when both are available.
- `POST /attestations/by-locus` now accepts each observable as an object with
  optional common RDF metadata; every property is written on that observable's
  newly created attestation, and invalid metadata rejects the complete batch.
- All entity metadata now shares one protection policy: properties in the
  OntoLex, FRAC, LIME, VarTrans, SynSem, SKOS, and Decomp namespaces, the three
  service-managed Dublin Core audit predicates, and RDF structural predicates
  are rejected on writes and omitted from metadata output.
- Lexical entry and attestation metadata values now reuse the common RDF
  metadata model and codec; lexical entry creation also returns its canonical
  metadata without changing the existing request contract.
- `POST /lexica/entry` now accepts multivalued RDF `metadata` directly on the
  lexical entry, while rejecting service-managed structural entry predicates.
- Newly created `lime:Lexicon` resources no longer receive a workflow status;
  `lexo:status` is assigned only to lexical entries.

- New lexical CRUD resource IRIs now normalize timestamp colons and decimal
  separators with `_` instead of `*`, producing identifiers that are safer to
  use in HTTP paths and downstream tools.
- Lexical sense `metadata` in `POST /lexica/entry` now uses the same
  `{property, values}` list structure as `properties`, with multiple RDF values
  supported for every metadata property.
- Attestation creation, deletion, and observable replacement now maintain one
  `frac:Frequency` per observable and specific text in the document attestation
  graph. Creation and retrieval items expose `frequency`; deletion and
  observable-update responses expose the resulting values by observable.
- Lexical concept creation now accepts optional `label` and ISO 639 `language`
  parameters, stores the value as a language-tagged `skos:prefLabel`, and
  returns the preferred label in the response's `label` field.
- Lexical concept list items now include the `attestations` count, computed from
  their `frac:attestation` links in the per-document attestation named graphs.
- Paginated attestation results now include an `observableLabel` resolved from
  OntoLex and SKOS labels, canonical written representations, and sense
  definitions according to the observable RDF type, preserving language tags
  when present.
- Paginated attestation results now expose custom attestation metadata grouped
  by property IRI, excluding globally protected vocabulary namespaces, RDF
  structural predicates, and Dublin Core audit properties.
- Both paginated attestation services now accept bounded, nested `AND`/`OR`
  filters for exact attestation creators, typed text metadata, and multiple
  observable types; type matching includes `rdfs:subClassOf` hierarchies.
- Both paginated attestation retrieval services now default to 50 results per
  page when `limit` is omitted.
- TXT and CommonMark uploads now require an ISO 639-1, ISO 639-2, or ISO 639-3
  language code. The validated code is written as `dcterms:language` in the NIF;
  `language` values in file front matter are ignored.
- Attestation creation now accepts a JSON list of textual occurrences and
  creates all corresponding FRAC attestations and NIF loci as one validated
  batch. NIF anchors, FRAC glosses, and RDF values now inherit the text's
  language metadata when available.
- NIF loci created by attestation services are now marked with
  `prov:wasGeneratedBy lexo:AttestationService`; deletion removes such a locus
  only after its final attestation is removed, while reused loci are preserved.
- The default LexO application namespace is now `https://lexo.ilc.cnr.it#`.
- Text persistence now uses a dedicated GraphDB repository instead of the
  lexical repository.
- Repository access utilities now route reads and writes to the correct
  repository at runtime.
- Lexical evidence, attestations, and annotations now use named graphs instead
  of the default graph.
- LexO-server now runs under the `/LexO-server` context path with fixed local
  GraphDB repositories.
- Bootstrap schema and repository configuration now come from versioned
  resources under `src/main/resources/bootstrap`.
- `description` metadata is now mapped into `dcterms:description` in text
  conversion and catalog responses.
- SKOS API documentation now treats authorization parameters as optional.

### Fixed

- LexInt historical verification now fails closed when publication links or
  provenance metadata are damaged, persists diagnostic `INDETERMINATE`
  reports, returns version audit history, rejects malformed Bearer headers
  before provider access, and prevents graph-family configuration collisions.

- WordNet detail projections now honor explicit `sections` without leaking
  unrequested core/native fields, and Synset/Sense relation sections support
  validated incoming/outgoing direction filtering.
- WordNet integrity and concurrency checks now reject shared RDF-list cells,
  extra Lexicon roots, malformed Sense/Synset ownership and stale workflow
  transitions transactionally; the WordNet pool size also remains independent
  from lexical repository configuration.
- WordNet member-list rewrites now validate existing list ownership before
  unlinking the head, so adding, moving, reordering or deleting multiple Senses
  no longer misclassifies a valid `rdf:rest` chain as shared list storage.
- WordNet repository and schema bootstrap now completes before lexical or text
  bootstrap mutation, preventing WordNet-specific startup failures from
  changing `LexOLexica` or `LexOTexts`.
- The WordNet registry collection now applies the shared deterministic
  ascending-IRI ordering before pagination.
- WordNet mutations and relation filters now reject explicitly typed but
  structurally orphaned Entry, Synset or Sense resources, and Sense PATCH no
  longer treats a null `subcategorizationIds` value as an empty replacement.
  Dedicated Entry workflow operations and Synset definition source references
  now apply the same ownership validation.
- Application readiness now requires the dedicated `LexOWordnets` repository
  in addition to bootstrap, `LexOLexica`, and `LexOTexts`, and reports its
  availability in the health response.

- Case-insensitive full-text queries now pass the original Lucene expression to
  the parser, preserving uppercase `AND`, `OR`, and `NOT`, quoted lowercase
  words, parentheses, and escapes. NFC and case normalization are applied by
  the field Analyzer, including prefix, wildcard, fuzzy, and regex terms;
  case-sensitive searches use the corresponding case-preserving fields.

- Container configuration overrides are now applied to the effective runtime
  properties, so Compose connects LexO to the internal `graphdb` service and
  honors storage, retry, and other `LEXO_*` values instead of packaged defaults.
- Docker source builds now install the vendored `OntoApi` artifact before the
  offline dependency-resolution layer, and the timestamp test accepts both UTC
  `Z` and numeric offsets so clean builds work in container time zones.
- Deleting a text now removes every lexical-repository statement whose subject
  or object is one of that text's attestations, including dangling cross-graph
  references, and recalculates affected observable frequencies in other valid
  per-document graphs while preserving their remaining attestations.
- Lexical concept creation and modification now validate each linked sense in
  its declared ISO language graph while keeping `ontolex:lexicalizedSense` in
  the fixed lexical-concept graph; requests use language-aware `senses`
  objects, and the ambiguous legacy `senseId` input is rejected.
- Lexical concept creation and modification now link a concept to its senses
  with `ontolex:lexicalizedSense`; updating `senses` also removes triples
  previously written with the inverse `ontolex:isLexicalizedSenseOf` predicate.
- `POST /lexica/lexicalConcept` no longer requires a metadata property when the
  optional `metadata` member is supplied as an empty array.
- RDF-valued JSON requests for lexical entries, lexical concepts, common
  metadata, and attestations now consistently accept `type` values `literal`
  and `iri` without MOXy mistaking them for Java class discriminators.
- Attestation creation and retrieval now resolve `observableTypes` and
  `observableLabel` from the observable's actual category named graph instead
  of the legacy lexical graph.
- Timestamp-based attestation IRI generation now advances to the next available
  millisecond when several attestations are created with the same clock value,
  preventing intermittent `ATTESTATION_ID_CONFLICT` build failures.
- Attestation creation now reuses an existing NIF word, sentence, or structural
  locus when its anchor, offsets, and reference context match, instead of
  reporting a false `LOCUS_CONFLICT` because its RDF types differ.
- Exact lexical entry and dictionary entry lookups now work even when labels are
  missing.
- Text import and conversion now clean up partial files and directories when an
  error occurs.
- Front matter IRIs are preserved correctly, including bracketed IRI forms.
- Repository statistics and text metadata handling now support mixed literal/IRI
  values and multiple values per metadata key.

### Removed

- Runtime log files are no longer versioned, and the programmatic Log4j 1 file
  appender plus the competing Logback configuration have been removed.
- The duplicate `PATCH /attestations/{fileId}/metadata` endpoint and its
  attestation-specific batch DTOs were removed; attestation metadata CRUD now
  uses the common `/metadata` service exclusively.
- Attestation descriptions were removed from both `POST /attestations` and the
  paginated `POST /attestations/{fileId}` contract; new attestations no longer
  persist `dcterms:description`.
- Legacy database and repository services backed by MySQL/Hibernate were
  removed from the application.

No Git tags were found yet, so there are no release comparison links to list at
the end of this changelog.
