# Baseline versus corrected evaluation

Baseline run: `dsh2027-20261121T072523Z-82217` (reported 12/12, but T09 was L0-only and CQ EXACT used permissive predicates). Corrected run: `dsh2027-corrected-20261121-77d2c3e`.

| Area | Baseline | Corrected observed behavior |
|---|---|---|
| T09 | MemoryStore L0 evidence consumed by E2E | T09-L0=PASSED; T09-GraphDB=PASSED; exact rollback and reset success path |
| CQ01–CQ07 | Counts plus independent value predicates | 7/7 exact complete RDF-term multisets; adversarial associations rejected |
| CE1–CE3 | 3 discrepancy cases detected | 3 cases recomputed; outcomes in `comparison.csv` |
| Aggregate T01–T12 | Reported 12 passed | 12 passed, 0 failed, 0 blocked, 0 not run |

The baseline archive and run ID are preserved; no old result file was copied into the corrected result directory.
