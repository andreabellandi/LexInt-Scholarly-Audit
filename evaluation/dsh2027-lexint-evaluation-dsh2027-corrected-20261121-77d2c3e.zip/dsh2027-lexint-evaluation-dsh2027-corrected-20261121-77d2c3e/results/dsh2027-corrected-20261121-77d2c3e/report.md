# DSH 2027 LexInt evaluation report

Run `dsh2027-corrected-20261121-77d2c3e` evaluated base revision `77d2c3e93b96a4ac0a4f2e6f98f9c40e781079ad` against a dedicated GraphDB stack. Identity assurance was `DECLARED`; this is not strong authentication.

## What we tried

T1–T12 publication, rejection, rollback, retry, writer-boundary and historical-audit cases, plus CQ1–CQ7 and CE1–CE3 in `all` mode. T09 used the deployed GraphDB repository through RDF4J HTTPRepository and an internal test-only post-write/pre-commit hook.

## What the dictionary published

See `tests.csv` and the RDF artifacts. Frozen expected graphs, rather than REST preview output, were used as the oracle.

## What was prevented

Rejected plans and managed writer calls were checked for graph and ledger side effects. The external GraphDB boundary is a property of the dedicated Docker topology.

## What was recovered

7 of 7 competency questions were recovered exactly by full typed-binding multiset comparison. Four adversarial row mutations were rejected.

## What remains unproved

The experiment does not establish the historical truth of an etymology, a new sense distinction, UI usability, multi-instance serializability, or RDF 1.2 support.

Execution counts: PASSED=12, FAILED=0, BLOCKED=0.
